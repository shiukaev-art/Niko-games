'use strict';
const $=id=>document.getElementById(id),GAMES=['snake','tetris','runner','obby','sudoku','neon-classic','magic'];let selected='snake',wantedGame=null,requestId=0,myId='',ready=false,allEntries=[],offset=0,total=0;
async function identity(){const p=Arcade.read().profile;if(p?.id){myId=p.id;return}if(p&&crypto.subtle){const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(p.token));myId=Array.from(new Uint8Array(d),x=>x.toString(16).padStart(2,'0')).join('')}}
function refreshProfile(){const s=Arcade.read(),p=s.profile;$('profile').textContent=p?p.name.slice(0,1).toUpperCase():'?';$('greeting').textContent=p?'Привет, '+p.name+'! Какой рекорд побьём сегодня?':'Выбери игру и поймай свой ритм.';for(const g of GAMES)$(g+'-best').textContent=(s.best[g]||PremiumStore.read().best[g]||0).toLocaleString('ru-RU');$('net').textContent=navigator.onLine?'● Интернет':'○ Без интернета';$('sync-note').textContent=Object.keys(s.pending).length?'Рекорды сохранены на этом устройстве под твоим именем.':'Лучшие результаты сохраняются под твоим именем.'}
function openName(game=null){wantedGame=game;const p=Arcade.read().profile;$('player-name').value=p?.name||'';$('name-error').textContent='';$('name-dialog').showModal()}
$('profile').onclick=()=>openName();$('name-close').onclick=()=>$('name-dialog').close();$('name-form').onsubmit=e=>{e.preventDefault();try{Arcade.create($('player-name').value);$('name-dialog').close();refreshProfile();if(wantedGame)location.href=wantedGame==='neon-classic'?'/Niko-games/premium/neon.html':wantedGame==='magic'?'/Niko-games/premium/magic.html':'/Niko-games/games/'+wantedGame+'.html';else loadRank()}catch(err){$('name-error').textContent=err.message}};
document.querySelectorAll('[data-play]').forEach(a=>a.addEventListener('click',()=>{Arcade.ensureProfile?.()}));
function render(entries){const host=$('entries');host.replaceChildren();if(!entries.length){const el=document.createElement('div');el.className='empty';el.textContent='Пока нет рекордов. Сыграй первым — твоё имя появится здесь!';host.append(el);return}entries.forEach(row=>{const el=document.createElement('div');el.className='rank-row'+(row.player===myId?' me':'');const place=document.createElement('span');place.className='place';place.textContent=row.rank<=3?['🥇','🥈','🥉'][row.rank-1]:String(row.rank).padStart(2,'0');const name=document.createElement('span');name.textContent=row.name;const tag=document.createElement('small');tag.textContent=row.player===myId?'это ты':'#'+row.player.slice(0,4);name.append(tag);const score=document.createElement('span');score.textContent=Number(row.score).toLocaleString('ru-RU');el.append(place,name,score);host.append(el)})}

const HAS_SERVER = !!window.NIKO_API_BASE || !location.hostname.endsWith('.github.io');
function localRanking(game){
  const s=Arcade.read(), nick=s.profile?.name||'Гость';
  const score=Number(s.best?.[game]||PremiumStore.read().best?.[game]||0);
  return score>0?[{rank:1,player:myId||'local',name:nick,score}]:[];
}
function renderLocalRanking(game){
  const entries=localRanking(game);allEntries=entries;total=entries.length;
  render(entries);showPlace({total,me:entries[0]||null});
  $('more').hidden=true;
  $('rank-note').textContent='Личные рекорды на этом устройстве';
  if(!entries.length) $('rank-note').textContent='Рекорды появятся после первой игры';
}
function onlineStats(){
  const host=document.getElementById('online-players');
  const note=document.getElementById('online-note');
  if(!host||!note)return;
  host.replaceChildren();
  const player=Arcade.read().profile;
  if(player){const el=document.createElement('span');el.className='online-player';el.textContent='● '+player.name+' (это ты)';host.append(el)}
  note.textContent=!navigator.onLine?'Офлайн · Локальные рекорды доступны.':
    (HAS_SERVER?'Есть интернет · список игроков обновляется сервером, когда он доступен.':
    'Общий список игроков онлайн требует сервер статистики. GitHub Pages хранит только файлы сайта.');
}

function showPlace(data){$('my-rank').textContent=data.me?'Твоё место: №'+data.me.rank+' из '+data.total+' · Рекорд: '+Number(data.me.score).toLocaleString('ru-RU'):data.total?'Участников: '+data.total+'. Сыграй, чтобы попасть в рейтинг.':''}
async function loadRank(more=false){await identity();const game=selected,id=++requestId;if(!more){offset=0;allEntries=[]}for(const g of GAMES){$('tab-'+g).classList.toggle('active',g===game);$('tab-'+g).setAttribute('aria-pressed',String(g===game))}$('units').textContent=game==='snake'?'ФРУКТЫ':'ОЧКИ';$('rank-note').textContent='Загружаем рейтинг…';$('more').disabled=true;let cached;try{cached=JSON.parse(localStorage.getItem('arcade-rank-'+game))}catch{}if(cached&&!more){render(cached.entries);showPlace(cached)}if(!HAS_SERVER){renderLocalRanking(game);onlineStats();$('more').disabled=false;return;}try{const r=await fetch((window.NIKO_API_BASE||'')+'/api/leaderboard?game='+game+'&offset='+offset+(myId?'&player='+myId:''),{cache:'no-store',signal:AbortSignal.timeout(9000)});if(!r.ok)throw Error('network');const data=await r.json();if(id!==requestId)return;allEntries=more?allEntries.concat(data.entries):data.entries;offset=allEntries.length;total=data.total;try{localStorage.setItem('arcade-rank-'+game,JSON.stringify({...data,entries:allEntries}))}catch{}render(allEntries);showPlace(data);$('more').hidden=offset>=total;$('rank-note').textContent='Общий рейтинг · '+(game==='neon-classic'?'NEON SNAKE: классика. Другие режимы — внутри игры.':game==='snake'?'съеденные фрукты':'очки за игру')}catch{if(id!==requestId)return;$('more').hidden=true;if(cached){allEntries=cached.entries;render(cached.entries);showPlace(cached);$('rank-note').textContent='Сохранённый рейтинг · '+new Date(cached.updatedAt).toLocaleString('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}else{$('entries').replaceChildren();const el=document.createElement('div');el.className='empty';el.textContent='Нет связи с рейтингом. Играть можно — твои рекорды сохранятся на устройстве.';$('entries').append(el);$('rank-note').textContent='Рейтинг появится при подключении';$('my-rank').textContent=''}}finally{$('more').disabled=false}}
GAMES.forEach(g=>$('tab-'+g).onclick=()=>{selected=g;loadRank()});$('more').onclick=()=>loadRank(true);$('refresh').onclick=async()=>{await Arcade.sync();loadRank()};$('share').onclick=async()=>{const url=location.origin+'/Niko-games/club.html';try{if(navigator.share)await navigator.share({title:'NIKO ARCADE — Игры для друзей',url});else{await navigator.clipboard.writeText(url);$('share').textContent='Ссылка скопирована ✓';setTimeout(()=>$('share').textContent='Поделиться клубом ↗',2500)}}catch{}};
function offlineState(state=window.ArcadePWA?.state){
ready=state?.ready===true;
$('offline').textContent=ready?'Все игры и ресурсы сохранены для офлайн ✓':
state?.coreReady?'Основные игры готовы офлайн ✓ · дополнительные файлы загружаются':
state?.supported===false?'Можно играть онлайн · офлайн-сохранение недоступно':
navigator.onLine?'Игры доступны онлайн · готовим офлайн-копию…':
'Без интернета. Для офлайн-копии открой клуб с интернетом один раз.';
}
window.addEventListener('arcade-change',()=>{refreshProfile();onlineStats()});window.addEventListener('arcade-synced',()=>loadRank());window.addEventListener('arcade-offline-state',e=>offlineState(e.detail));window.addEventListener('arcade-storage-error',()=>document.body.classList.add('storage-error'));window.addEventListener('online',()=>{refreshProfile();loadRank();offlineState()});window.addEventListener('offline',()=>{refreshProfile();offlineState()});refreshProfile();loadRank();offlineState();onlineStats();

$("theme").value=ArcadePhotos.theme();$("theme").onchange=()=>{ArcadePhotos.setTheme($("theme").value);$("theme-status").textContent="Сохранено. Выбранные фоны появятся в новой партии."};

window.addEventListener('online',onlineStats);window.addEventListener('offline',onlineStats);
