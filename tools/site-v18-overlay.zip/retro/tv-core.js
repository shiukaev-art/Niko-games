/* TV transport: controller snapshots only, with a LAN DataChannel and HTTP fallback. */
(() => {
  'use strict';
  const N = window.NikoNetplay, MASK = 0x0fff;
  function secret() { return N.token() + N.token(); }
  async function post(action, payload, signal, options = {}) {
    const controller = new AbortController(), abort = () => controller.abort();
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(abort, options.timeout || 4500);
    try {
      const response = await fetch('/api/retro-tv', { method: 'POST', credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer', keepalive: !!options.keepalive,
        headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, ...payload }), signal: controller.signal });
      const data = await response.json();
      if (!response.ok) { const error = new Error(data.error || 'TV-комната недоступна.'); error.status = response.status; throw error; }
      return data;
    } catch (error) {
      if (signal?.aborted) throw error;
      if (error.name === 'AbortError' || error instanceof TypeError) throw new Error('Связь с телевизором прервалась. Проверь сеть: подключение восстановится автоматически.');
      throw error;
    } finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
  }
  function receiver(session, apply, now = () => performance.now()) {
    let sequence = -1, pressed = 0, deadline = 0;
    function set(mask) {
      const changed = pressed ^ mask;
      for (let index = 0; index < 12; index++) if (changed & (1 << index)) apply(index, (mask >> index) & 1);
      pressed = mask;
    }
    return {
      receive(value, elapsed = 0) {
        if (!value || value.session !== session || !Number.isSafeInteger(value.seq) || value.seq < 0 || value.seq <= sequence || !Number.isInteger(value.mask) || value.mask < 0 || value.mask > MASK || !Number.isFinite(value.age) || value.age < 0 || !Number.isFinite(elapsed) || elapsed < 0) return false;
        sequence = value.seq;
        const lifetime = 700 - value.age - elapsed;
        if (lifetime <= 0) { set(0); return false; }
        deadline = now() + lifetime; set(value.mask); return true;
      },
      release() { set(0); },
      tick() { if (pressed && now() >= deadline) set(0); }
    };
  }
  function direct({ role, session, onInput = () => {}, onStatus = () => {} }) {
    if (typeof RTCPeerConnection !== 'function') return null;
    const pc = new RTCPeerConnection({ iceServers: [], bundlePolicy: 'max-bundle' });
    let channel, closed = false, connected = false, mask = 0, seq = 0, accepted = false, deadline;
    const abort = new AbortController(), sink = N.inputReceiver(session, onInput);
    function send() {
      if (closed || role !== 'phone' || channel?.readyState !== 'open' || channel.bufferedAmount > 4096) return;
      try { channel.send(JSON.stringify({ t: 'pad', sid: session, seq: seq++, mask, stamp: performance.now() })); } catch { close(); }
    }
    function close() {
      if (closed) return;
      if (role === 'phone' && channel?.readyState === 'open') try { channel.send(JSON.stringify({ t: 'pad', sid: session, seq: seq++, mask: 0, stamp: performance.now() })); } catch {}
      mask = 0; closed = true; connected = false; sink.release(); abort.abort();
      clearInterval(timer); clearTimeout(deadline);
      try { channel?.close(); } catch {} try { pc.close(); } catch {}
      onStatus('fallback');
    }
    function attach(next) {
      if (channel || next.label !== 'niko-tv-pad' || next.protocol !== 'niko-tv-v1') { next.close(); return; }
      channel = next;
      channel.addEventListener('open', () => { if (closed) return; connected = true; clearTimeout(deadline); onStatus('direct'); send(); });
      channel.addEventListener('message', event => { if (!closed && role === 'tv') sink.receive(event.data); });
      channel.addEventListener('close', close); channel.addEventListener('error', close);
    }
    pc.addEventListener('datachannel', event => { if (role === 'phone') attach(event.channel); else event.channel.close(); });
    const check = () => {
      if (['failed', 'disconnected', 'closed'].includes(pc.connectionState || pc.iceConnectionState)) close();
    };
    pc.addEventListener('connectionstatechange', check); pc.addEventListener('iceconnectionstatechange', check);
    if (role === 'tv') attach(pc.createDataChannel('niko-tv-pad', { ordered: false, maxRetransmits: 0, protocol: 'niko-tv-v1' }));
    const timer = setInterval(() => role === 'tv' ? sink.tick() : send(), 100);
    function ensure() { if (closed) throw new DOMException('Aborted', 'AbortError'); }
    async function gather() {
      ensure();
      if (pc.iceGatheringState !== 'complete') await new Promise((resolve, reject) => {
        let timeout;
        const cleanup = () => { clearTimeout(timeout); pc.removeEventListener('icegatheringstatechange', changed); abort.signal.removeEventListener('abort', cancelled); };
        const done = () => { cleanup(); resolve(); };
        const changed = () => { if (pc.iceGatheringState === 'complete') done(); };
        const cancelled = () => { cleanup(); reject(new DOMException('Aborted', 'AbortError')); };
        pc.addEventListener('icegatheringstatechange', changed); abort.signal.addEventListener('abort', cancelled, { once: true });
        timeout = setTimeout(done, 5000); changed();
      });
      ensure();
      if (!/^a=candidate:/m.test(pc.localDescription?.sdp || '')) throw new Error('Нет прямого канала; используем сервер.');
      return { type: pc.localDescription.type, sdp: pc.localDescription.sdp };
    }
    function wait() { clearTimeout(deadline); deadline = setTimeout(() => { if (!connected) close(); }, 15000); }
    return {
      get connected() { return connected && !closed; },
      async offer() { ensure(); await pc.setLocalDescription(await pc.createOffer()); return gather(); },
      async answer(offer) { ensure(); await pc.setRemoteDescription(offer); ensure(); await pc.setLocalDescription(await pc.createAnswer()); const value = await gather(); wait(); return value; },
      async accept(answer) { ensure(); if (accepted) return; accepted = true; await pc.setRemoteDescription(answer); ensure(); wait(); },
      setMask(value) { mask = Number.isInteger(value) ? value & MASK : 0; send(); },
      release() { mask = 0; send(); sink.release(); }, close
    };
  }
  window.NikoTV = { post, receiver, direct, secret };
})();
