/* NIKO remote play, protocol 1. Offline codes use LAN; online invites use configured ICE. */
(() => {
  'use strict';
  const PROTOCOL = 'niko-pad-v1', PREFIX = 'NIKO-WIFI1.', MAX_SDP = 48000;
  const SYSTEMS = ['segaMD', 'nes', 'snes'];
  const MASK = 0x0fff, MAX_CODE = 90000;
  const token = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), n => n.toString(16).padStart(2, '0')).join('');
  const fail = message => { throw new Error(message); };
  function supported() {
    return typeof RTCPeerConnection === 'function' && typeof MediaStream === 'function';
  }
  function validPacket(packet, kind) {
    if (!['offer', 'answer'].includes(kind)) return false;
    if (!packet || packet.v !== 1 || packet.kind !== kind || typeof packet.sid !== 'string' || !/^[a-f0-9]{32}$/.test(packet.sid)) return false;
    if (!SYSTEMS.includes(packet.system) || typeof packet.game !== 'string' || !packet.game.trim() || packet.game.length > 140 || /[\p{Cc}\p{Cf}<>]/u.test(packet.game)) return false;
    const description = packet.description;
    return description?.type === kind && typeof description.sdp === 'string' && description.sdp.length <= MAX_SDP && /^v=0\r?\n/.test(description.sdp);
  }
  function encode(packet) {
    if (!validPacket(packet, packet?.kind)) fail('Некорректный код соединения.');
    const bytes = new TextEncoder().encode(JSON.stringify(packet));
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    const code = PREFIX + btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    if (code.length > MAX_CODE) fail('Код соединения слишком большой. Попробуй создать новое приглашение.');
    return code;
  }
  function decode(value, kind) {
    try {
      if (typeof value !== 'string' || value.length > MAX_CODE + 4000) throw new Error();
      const code = value.replace(/\s/g, '');
      if (!code.startsWith(PREFIX) || code.length > MAX_CODE) throw new Error();
      const encoded = code.slice(PREFIX.length);
      if (!/^[A-Za-z0-9_-]+$/.test(encoded)) throw new Error();
      const binary = atob(encoded.replace(/-/g, '+').replace(/_/g, '/'));
      const packet = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(binary, c => c.charCodeAt(0))));
      if (!validPacket(packet, kind)) throw new Error();
      return packet;
    } catch { fail('Код не подходит. Скопируй его целиком, начиная с NIKO-WIFI1.'); }
  }
  async function signal(action, payload, signal) {
    const controller = new AbortController();
    const abort = () => controller.abort();
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(abort, 12000);
    try {
      const response = await fetch('/api/retro-room', {
        method: 'POST', credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer',
        headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, ...payload }), signal: controller.signal
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || 'Не удалось связаться с комнатой.');
      return data;
    } catch (error) {
      if (signal?.aborted) throw error;
      if (error.name === 'AbortError' || error instanceof TypeError) fail('Сервер соединения не ответил. Проверь интернет или выбери обмен кодами без интернета.');
      throw error;
    } finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
  }
  async function ice(signal) {
    const controller = new AbortController(), abort = () => controller.abort();
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(abort, 10000);
    try {
      const response = await fetch('/api/retro-ice', { credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer', signal: controller.signal });
      const data = await response.json();
      if (!response.ok || !Array.isArray(data.iceServers) || data.iceServers.length > 10) throw new Error('Не удалось получить настройки сетевой игры. Попробуй ещё раз.');
      return { iceServers: data.iceServers, relayAvailable: data.relayAvailable === true };
    } finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
  }
  function gather(pc, signal) {
    if (pc.iceGatheringState === 'complete') return Promise.resolve();
    return new Promise((resolve, reject) => {
      let timer;
      const finish = error => {
        clearTimeout(timer); pc.removeEventListener('icegatheringstatechange', update); signal?.removeEventListener('abort', abort);
        error ? reject(error) : resolve();
      };
      const update = () => { if (pc.iceGatheringState === 'complete') finish(); };
      const abort = () => finish(new DOMException('Aborted', 'AbortError'));
      pc.addEventListener('icegatheringstatechange', update);
      signal?.addEventListener('abort', abort, { once: true });
      timer = setTimeout(() => finish(/^a=candidate:/m.test(pc.localDescription?.sdp || '') ? undefined : new Error('Браузер не подготовил адрес для связи. Проверь подключение и попробуй снова.')), 10000);
      if (signal?.aborted) abort(); else update();
    });
  }
  function inputReceiver(sid, apply, now = () => performance.now()) {
    let pressed = 0, sequence = -1, stamp = -1, seen = 0, bestOffset = Infinity, count = 0, period = now();
    function release() {
      for (let id = 0; id < 12; id++) if (pressed & (1 << id)) apply(id, 0);
      pressed = 0;
    }
    function receive(raw) {
      if (typeof raw !== 'string' || raw.length > 240) return false;
      let data;
      try { data = JSON.parse(raw); } catch { return false; }
      if (!data || data.t !== 'pad' || data.sid !== sid || !Number.isSafeInteger(data.seq) || data.seq <= sequence || data.seq < 0 || !Number.isInteger(data.mask) || data.mask < 0 || data.mask > MASK || !Number.isFinite(data.stamp) || data.stamp < stamp || data.stamp < 0) return false;
      const time = now();
      if (time - period > 1000) { period = time; count = 0; }
      if (++count > 120) { release(); return false; }
      const offset = time - data.stamp;
      bestOffset = Math.min(bestOffset, offset);
      // An unordered, non-retransmitted channel plus complete snapshots prevents
      // old keydowns overtaking releases. Drop delayed packets as well.
      if (offset - bestOffset > 700) return false;
      sequence = data.seq; stamp = data.stamp; seen = time;
      const changed = pressed ^ data.mask;
      for (let id = 0; id < 12; id++) if (changed & (1 << id)) apply(id, (data.mask >> id) & 1);
      pressed = data.mask;
      return true;
    }
    return { receive, release, tick() { if (pressed && now() - seen > 550) release(); } };
  }
  function peer({ role, sid = token(), game, system, stream, iceServers = [], onStream = () => {}, onStatus = () => {}, onInput = () => {} }) {
    if (!supported()) fail('Этот браузер не поддерживает передачу игры. Открой Niko Arcade в актуальном Safari или Chrome.');
    if (!SYSTEMS.includes(system)) fail('Для этой приставки соединение двух игроков не поддерживается.');
    // Online credentials are short-lived and supplied by our endpoint. Manual
    // offline pairing deliberately leaves this list empty.
    const pc = new RTCPeerConnection({ iceServers, bundlePolicy: 'max-bundle' });
    const controller = new AbortController(), remote = new MediaStream();
    let channel, closed = false, connected = false, answerSet = false, sequence = 0, mask = 0, disconnectedTimer, connectTimer;
    const receiver = inputReceiver(sid, onInput);
    const timer = setInterval(() => {
      if (role === 'host') receiver.tick(); else send();
    }, 100);
    function status(value) { if (!closed) onStatus(value); }
    function send() {
      if (closed || role !== 'guest' || channel?.readyState !== 'open') return;
      if (channel.bufferedAmount > 16384) return; // Host dead-man timer releases held inputs.
      try { channel.send(JSON.stringify({ t: 'pad', sid, seq: sequence++, mask, stamp: performance.now() })); } catch { receiver.release(); }
    }
    function close(reason = 'closed') {
      if (closed) return;
      if (role === 'guest') { mask = 0; send(); }
      closed = true; receiver.release(); clearInterval(timer); clearTimeout(disconnectedTimer); clearTimeout(connectTimer);
      controller.abort(); try { channel?.close(); } catch {} try { pc.close(); } catch {}
      remote.getTracks().forEach(track => track.stop());
      onStatus(reason);
    }
    function opened() {
      if (closed || channel?.readyState !== 'open') return;
      clearTimeout(disconnectedTimer); clearTimeout(connectTimer);
      if (!connected) { connected = true; status('connected'); }
      send();
    }
    function attach(next) {
      if (channel || next.label !== 'niko-pad' || next.protocol !== PROTOCOL) { next.close(); return; }
      channel = next; channel.binaryType = 'arraybuffer';
      channel.addEventListener('open', opened);
      channel.addEventListener('message', event => { if (role === 'host' && !closed) receiver.receive(event.data); });
      channel.addEventListener('close', () => close('disconnected'));
      channel.addEventListener('error', () => close('disconnected'));
      if (channel.readyState === 'open') opened();
    }
    pc.addEventListener('datachannel', event => { if (role === 'guest') attach(event.channel); else event.channel.close(); });
    pc.addEventListener('track', event => {
      if (closed || role !== 'guest') return;
      if (!remote.getTracks().some(track => track.id === event.track.id)) remote.addTrack(event.track);
      onStream(remote);
    });
    function stateChanged() {
      if (closed) return;
      const state = pc.connectionState || pc.iceConnectionState;
      if (state === 'failed' || state === 'closed') close('failed');
      else if (state === 'disconnected') {
        receiver.release(); mask = 0; status('interrupted');
        if (!disconnectedTimer) disconnectedTimer = setTimeout(() => close('disconnected'), 8000);
      } else if (state === 'connected' || state === 'completed') {
        clearTimeout(disconnectedTimer); disconnectedTimer = undefined;
        opened();
        if (connected) status('connected');
      }
    }
    pc.addEventListener('connectionstatechange', stateChanged);
    pc.addEventListener('iceconnectionstatechange', stateChanged);
    if (role === 'host') {
      if (!stream?.getVideoTracks().length) { close(); fail('Не удалось получить изображение игры.'); }
      stream.getTracks().forEach(track => pc.addTrack(track, stream));
      attach(pc.createDataChannel('niko-pad', { ordered: false, maxRetransmits: 0, protocol: PROTOCOL }));
    }
    function ensure() { if (closed) throw new DOMException('Aborted', 'AbortError'); }
    function packet(kind) { return { v: 1, kind, sid, game: String(game).slice(0, 140), system, description: { type: kind, sdp: pc.localDescription.sdp } }; }
    function candidateCheck() {
      if (!/^a=candidate:/m.test(pc.localDescription?.sdp || '')) fail('Браузер не предоставил локальный адрес для связи. Открой игру в обычном Safari или Chrome и проверь подключение. В этой среде прямое соединение недоступно.');
    }
    function waitForConnection() {
      if (connected || closed) return;
      clearTimeout(connectTimer);
      connectTimer = setTimeout(() => close('timeout'), 35000);
    }
    return {
      sid, pc, signal: controller.signal,
      get connected() { return connected && !closed; },
      async offer() {
        ensure(); await pc.setLocalDescription(await pc.createOffer()); await gather(pc, controller.signal); ensure(); candidateCheck(); return packet('offer');
      },
      async answer(offer) {
        if (!validPacket(offer, 'offer') || offer.sid !== sid) fail('Некорректное приглашение.');
        ensure(); await pc.setRemoteDescription(offer.description); ensure();
        await pc.setLocalDescription(await pc.createAnswer()); await gather(pc, controller.signal); ensure(); candidateCheck();
        // Manual exchange may take minutes. Start connection timeout only when
        // the guest explicitly confirms that the host has received this answer.
        return packet('answer');
      },
      async accept(answer) {
        if (!validPacket(answer, 'answer') || answer.sid !== sid || answer.system !== system || answer.game !== String(game).slice(0, 140)) fail('Это ответ от другой игры или старого приглашения. Создай новое соединение.');
        if (answerSet) fail('Ответ уже принят. Для нового игрока создай другое приглашение.');
        ensure(); await pc.setRemoteDescription(answer.description); ensure(); answerSet = true; waitForConnection();
      },
      waiting: waitForConnection,
      setMask(next) { mask = Number.isInteger(next) ? next & MASK : 0; send(); },
      release() { mask = 0; send(); receiver.release(); },
      close
    };
  }
  function capture(emulator) {
    const canvas = emulator?.canvas;
    if (!canvas?.captureStream) fail('Этот браузер не умеет передавать изображение игры. Попробуй актуальный Safari или Chrome.');
    const stream = canvas.captureStream(30), nodes = new Set();
    if (!stream.getVideoTracks().length) { stream.getTracks().forEach(track => track.stop()); fail('Не удалось получить изображение игры.'); }
    let destination, context, timer;
    function disconnectAudio() {
      clearInterval(timer);
      for (const node of nodes) try { node.disconnect(destination); } catch {}
      nodes.clear(); try { destination?.disconnect(); } catch {}
    }
    const al = emulator.Module?.AL?.currentCtx;
    if (typeof al?.audioCtx?.createMediaStreamDestination === 'function') try {
      context = al.audioCtx;
      try { Promise.resolve(context.resume?.()).catch(() => {}); } catch {}
      destination = context.createMediaStreamDestination();
      const sync = () => {
        const current = new Set(Object.values(emulator.Module?.AL?.currentCtx?.sources || {}).map(source => source?.gain).filter(Boolean));
        for (const node of nodes) if (!current.has(node)) { try { node.disconnect(destination); } catch {} nodes.delete(node); }
        for (const node of current) if (!nodes.has(node) && node.context === context) try { node.connect(destination); nodes.add(node); } catch {}
      };
      sync();
      destination.stream.getAudioTracks().forEach(track => stream.addTrack(track));
      timer = setInterval(sync, 1000);
    } catch {
      disconnectAudio();
      for (const track of destination?.stream?.getAudioTracks?.() || []) { try { stream.removeTrack(track); } catch {} track.stop(); }
    }
    let stopped = false;
    return { stream, stop() {
      if (stopped) return; stopped = true; disconnectAudio();
      stream.getTracks().forEach(track => track.stop());
    } };
  }
  async function copy(text, field) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch { field?.focus(); field?.select(); return false; }
  }
  async function shareCode(code, name) {
    const file = new File([code], name + '.txt', { type: 'text/plain' });
    if (navigator.share) {
      try {
        if (navigator.canShare?.({ files: [file] })) await navigator.share({ title: 'Код игры NIKO ARCADE', files: [file] });
        else await navigator.share({ title: 'Код игры NIKO ARCADE', text: code });
        return 'shared';
      } catch (error) { if (error.name === 'AbortError') return 'cancel'; }
    }
    const link = document.createElement('a'), url = URL.createObjectURL(file);
    link.href = url; link.download = file.name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 10000);
    return 'saved';
  }
  async function readCode(file) {
    if (!file || file.size > MAX_CODE + 4000) fail('Выбери текстовый файл кода размером до 94 КБ.');
    return file.text();
  }
  window.NikoNetplay = { supported, validPacket, encode, decode, signal, ice, peer, capture, copy, shareCode, readCode, token, inputReceiver, SYSTEMS };
})();
