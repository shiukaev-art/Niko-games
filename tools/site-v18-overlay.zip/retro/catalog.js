(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RetroCatalog = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  let pending;
  function validate(data) {
    if (data?.version !== 1 || !Array.isArray(data.games) || data.games.length > 100) throw new Error('Не удалось прочитать каталог игр.');
    const ids = new Set(), paths = new Set(), hashes = new Set();
    return Object.freeze(data.games.map(item => {
      if (!item || typeof item.id !== 'string' || item.id.trim() !== item.id
        || !/^shared-[a-z0-9-]+$/.test(item.id) || ids.has(item.id)
        || typeof item.name !== 'string' || !item.name.trim() || item.name.length > 120
        || item.system !== 'segaMD' || typeof item.path !== 'string' || item.path.trim() !== item.path
        || !/^\/retro\/roms\/[a-z0-9-]+\.gen$/.test(item.path) || paths.has(item.path)
        || !Number.isSafeInteger(item.size) || item.size < 512 || item.size > 16 * 1024 * 1024
        || typeof item.sha256 !== 'string' || item.sha256.length !== 64
        || !/^[a-f0-9]{64}$/.test(item.sha256) || hashes.has(item.sha256)
        || ![1, 2].includes(item.players)) throw new Error('В каталоге повреждена запись картриджа.');
      ids.add(item.id);
      paths.add(item.path);
      hashes.add(item.sha256);
      return Object.freeze({ ...item, name: item.name.trim() });
    }));
  }
  function siteAsset(path){
    const base='/Niko-games';
    return path.startsWith(base+'/') ? path : base+path;
  }
  async function timedFetch(path, timeout) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const options = { signal: controller.signal, credentials: 'same-origin', redirect: 'error' };
      let response = await fetch(siteAsset(path), options);
      // If the active SW returned a stale synthetic error, try the real static file.
      if (!response.ok && navigator.onLine) {
        try { response = await fetch(siteAsset(path) + '?niko-direct=1', options); } catch {}
      }
      if (!response.ok) throw new Error(navigator.onLine ? 'Картридж не загрузился. Открой «Исправить загрузку» на главной странице и попробуй снова.' : 'Картридж ещё не сохранён. Подключись к сети и нажми «Скачать для офлайн».');
      return await response.blob();
    } finally { clearTimeout(timer); }
  }
  async function load() {
    if (!pending) pending = timedFetch('/Niko-games/retro/catalog.json', 15000)
      .then(blob => blob.text()).then(JSON.parse).then(validate).catch(error => { pending = null; throw error; });
    return pending;
  }
  async function read(id) {
    const item = (await load()).find(game => game.id === id);
    if (!item) return null;
    const file = await timedFetch(item.path, 45000);
    if (file.size !== item.size) throw new Error('Картридж загрузился не полностью. Повтори запуск при устойчивом соединении.');
    const bytes = await file.arrayBuffer();
    const header = new Uint8Array(bytes, 256, 4);
    if (String.fromCharCode(...header) !== 'SEGA') throw new Error('Вместо картриджа получен неверный файл. Повтори запуск.');
    if (typeof crypto === 'undefined' || !crypto.subtle || typeof crypto.subtle.digest !== 'function') {
      throw new Error('Браузер не поддерживает проверку целостности картриджа. Открой клуб по защищённой ссылке в Safari или Chrome.');
    }
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const hash = Array.from(new Uint8Array(digest), n => n.toString(16).padStart(2, '0')).join('');
    if (hash !== item.sha256) throw new Error('Проверка картриджа не пройдена. Подключись к сети и повтори скачивание.');
    return { ...item, file, shared: true };
  }
  return { validate, load, read };
});
