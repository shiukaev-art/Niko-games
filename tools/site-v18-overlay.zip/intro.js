(function(){
  'use strict';
  if(window.top!==window.self||document.documentElement.hasAttribute('data-no-intro')) return;
  const key='niko-intro-shiukaev-v18';
  try { if(sessionStorage.getItem(key)) return; sessionStorage.setItem(key,'1'); } catch {}
  function start(){
    const overlay=document.createElement('section');
    overlay.className='niko-intro'; overlay.setAttribute('role','dialog');
    overlay.setAttribute('aria-modal','true'); overlay.setAttribute('aria-label','NIKO ARCADE');
    const text=document.createElement('p'); text.className='niko-intro-main';
    text.textContent='This application was developed by Nikolai Shiukaev. I hope you’ll like it.';
    const skip=document.createElement('button'); skip.className='niko-intro-skip';
    skip.textContent='Играть →'; skip.type='button';
    const overflow=document.body.style.overflow;
    let finished=false;
    function finish(){ if(finished)return; finished=true; clearTimeout(timer);overlay.remove();document.body.style.overflow=overflow;document.removeEventListener('keydown',onkey,true); }
    function onkey(event){ if(event.key==='Escape'||event.key==='Enter'){event.preventDefault();finish();} }
    skip.addEventListener('click',finish);
    overlay.append(text,skip); document.body.appendChild(overlay); document.body.style.overflow='hidden';
    document.addEventListener('keydown',onkey,true);
    const timer=setTimeout(finish,2800);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
