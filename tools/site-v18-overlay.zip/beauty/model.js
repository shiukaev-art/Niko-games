/* Photo quiz state is independent of the DOM and safe to restore after closing. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.OssetianBeautyModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MODES = ['all', 'places', 'costumes'];
  const categories = ['north', 'south', 'costume'];
  // A corrected photo, focus box or Ossetian word changes the lesson just as an
  // answer correction does. Do not resume an old score against that new content.
  // Fixed field order also avoids delimiter collisions and ignores credit-only edits.
  const fingerprint = bank => JSON.stringify(bank.entries.map(e => [
    e.id, e.category, e.kind, e.region, e.titleRu, e.titleOs,
    e.question, e.answer, e.distractors, e.image, e.imageAlt,
    e.focus ? [e.focus.x, e.focus.y, e.focus.w, e.focus.h] : null,
    e.explanation, e.speechId,
    e.learningWord ? [e.learningWord.word, e.learningWord.meaning, e.learningWord.speechId] : null
  ]));
  function shuffle(items, random) {
    const result = [...items];
    for (let i = result.length - 1; i > 0; i--) {
      const value = Math.max(0, Math.min(.99999999, Number(random()) || 0));
      const j = Math.floor(value * (i + 1)); [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }
  function validateBank(bank) {
    const seen = new Set();
    return bank?.version === 1 && Array.isArray(bank.entries) && bank.entries.length > 0 && bank.entries.every(e => {
      if (!e || typeof e.id !== 'string' || !/^[a-z0-9-]+$/.test(e.id) || seen.has(e.id) || !categories.includes(e.category) ||
        !Array.isArray(e.distractors) || e.distractors.length !== 2 || ![e.answer, ...e.distractors].every(x => typeof x === 'string' && x.trim()) ||
        new Set([e.answer, ...e.distractors]).size !== 3 || typeof e.image !== 'string' || !/^\/beauty\/media\/[a-z0-9-]+\.(jpg|webp)$/.test(e.image)) return false;
      seen.add(e.id); return true;
    });
  }
  function pool(bank, mode) {
    return bank.entries.filter(e => mode === 'all' || (mode === 'costumes' ? e.category === 'costume' : e.category !== 'costume'));
  }
  function create(bank, mode = 'all', random = Math.random) {
    if (!validateBank(bank) || !MODES.includes(mode)) throw new Error('Invalid photo quiz bank');
    const available = pool(bank, mode);
    if (!available.length) throw new Error('Empty photo quiz');
    // Each mixed round visits both regions and clothing, without repeated questions.
    const groups = shuffle(categories, random).map(category => shuffle(available.filter(e => e.category === category), random));
    const picked = [];
    while (picked.length < Math.min(10, available.length)) {
      for (const group of groups) if (group.length && picked.length < Math.min(10, available.length)) picked.push(group.shift());
    }
    return { version: 1, bank: fingerprint(bank), mode, index: 0, finished: false,
      questions: picked.map(e => ({ id: e.id, order: shuffle([0, 1, 2], random), selected: null, skipped: false })) };
  }
  function restore(input, bank) {
    try {
      if (typeof input === 'string') input = JSON.parse(input);
      if (!validateBank(bank) || !input || input.version !== 1 || input.bank !== fingerprint(bank) || !MODES.includes(input.mode) ||
        !Number.isInteger(input.index) || typeof input.finished !== 'boolean' || !Array.isArray(input.questions) ||
        input.questions.length !== Math.min(10, pool(bank, input.mode).length) || input.index < 0 || input.index >= input.questions.length) return null;
      const allowed = new Set(pool(bank, input.mode).map(e => e.id)); const seen = new Set();
      for (let i = 0; i < input.questions.length; i++) {
        const q = input.questions[i];
        if (!q || !allowed.has(q.id) || seen.has(q.id) || !Array.isArray(q.order) || q.order.length !== 3 || !q.order.every(Number.isInteger) ||
          [...q.order].sort().join(',') !== '0,1,2' || (q.selected !== null && (!Number.isInteger(q.selected) || q.selected < 0 || q.selected > 2)) ||
          typeof q.skipped !== 'boolean' || (q.skipped && q.selected !== null)) return null;
        const done = q.selected !== null || q.skipped;
        if (i < input.index && !done || i > input.index && done) return null;
        seen.add(q.id);
      }
      if (input.finished && (input.index !== input.questions.length - 1 || !done(input.questions[input.index]))) return null;
      return { version: 1, bank: input.bank, mode: input.mode, index: input.index, finished: input.finished,
        questions: input.questions.map(q => ({ id: q.id, order: [...q.order], selected: q.selected, skipped: q.skipped })) };
    } catch { return null; }
  }
  function done(q) { return q.selected !== null || q.skipped; }
  function question(state, bank) {
    const q = state.questions[state.index], entry = bank.entries.find(e => e.id === q.id);
    return { ...entry, options: q.order.map(i => [entry.answer, ...entry.distractors][i]), correct: q.order.indexOf(0), selected: q.selected, skipped: q.skipped };
  }
  function answer(state, selected) {
    if (state.finished || done(state.questions[state.index]) || !Number.isInteger(selected) || selected < 0 || selected > 2) return state;
    const copy = JSON.parse(JSON.stringify(state)); copy.questions[state.index].selected = selected; return copy;
  }
  function skip(state) {
    if (state.finished || done(state.questions[state.index])) return state;
    const copy = JSON.parse(JSON.stringify(state)); copy.questions[state.index].skipped = true; return copy;
  }
  function next(state) {
    if (state.finished || !done(state.questions[state.index])) return state;
    return state.index === state.questions.length - 1 ? { ...state, finished: true } : { ...state, index: state.index + 1 };
  }
  function summary(state) {
    const answered = state.questions.filter(q => q.selected !== null).length;
    const correct = state.questions.filter(q => q.selected !== null && q.order[q.selected] === 0).length;
    return { total: state.questions.length, answered, correct, skipped: state.questions.filter(q => q.skipped).length, score: correct * 100 };
  }
  return { create, restore, question, answer, skip, next, summary, validateBank };
});
