(()=>{
const audio=NikoModernAudio.create('ossetia');audio.start();let enabled=true;document.getElementById('music').onclick=()=>{enabled=!enabled;audio.setEnabled(enabled);document.getElementById('music').textContent=enabled?'♫ Музыка':'♫ Тишина'};
const C='https://commons.wikimedia.org/wiki/Special:FilePath/';
const places=[
['Даргавс — некрополь','village','Пригородный район. Каменные фамильные склепы на склоне над долиной Гизельдона.','Dargavs. Crypt burial ground.jpg'],
['Даргавс — общий вид долины','nature','Даргавсская котловина. Панорама горной долины и исторической застройки.','North Ossetia–Alania. Dargavs Valley PA160523 2575.jpg'],
['Даргавс — селение','village','Горное селение Даргавс, рядом с некрополем.','North Ossetia–Alania. Dargavs PA160520 2575.jpg'],
['Город мёртвых — верхний ракурс','village','Высокая точка над Даргавсским некрополем.','North Ossetia–Alania. Dargavs\' City of the Dead PA160502 2400.jpg'],
['Река Гизельдон у Даргавса','nature','Гизельдонское ущелье, дорога к Даргавсу.','North Ossetia–Alania. Dargavs. River Gizeldon PA160500 2575.jpg'],
['Гизельдон — второй ракурс','nature','Русло Гизельдона и горные склоны у Даргавса.','North Ossetia–Alania. Dargavs. River Gizeldon PA160553 2575.jpg'],
['Кармадон — вход в ущелье','gorge','Геналдонское ущелье. Один из самых драматичных горных пейзажей Осетии.','Вход в Кармадонское ущелье.jpg'],
['Кармадонское ущелье','gorge','Дорога и высокие стены Геналдонского ущелья.','North Ossetia–Alania. Karmadon Gorge PA160388 2575.jpg'],
['Геналдон в Кармадоне','nature','Река Геналдон в Кармадонском ущелье.','North Ossetia–Alania. Karmadon Gorge. Genaldon River PA160408 2575.jpg'],
['Геналдон — каменное русло','nature','Ещё один вид реки и скальных стен Кармадона.','North Ossetia–Alania. Karmadon Gorge. Genaldon River PA160413 2575.jpg'],
['Кармадон — горная точка','gorge','Высокий ракурс на долину и дорогу.','North Ossetia–Alania. Karmadon PA160439 2575.jpg'],
['Кармадон — панорама','gorge','Открытая панорама верхней части ущелья.','North Ossetia–Alania. Karmadon PA160446 2575.jpg'],
['Кармадон — скалы','gorge','Скалистая часть долины Геналдона.','North Ossetia–Alania. Karmadon PA160468 2575.jpg'],
['Кармадон — дальний вид','gorge','Широкий горный ракурс Кармадонского направления.','North Ossetia–Alania. Karmadon PA160470 2575.jpg'],
['Кармадон — зелёная долина','gorge','Летний вид горного ландшафта.','North Ossetia–Alania. Karmadon PA160474 2575.jpg'],
['Куртатинское ущелье — каньон 1','gorge','Куртатинская долина, скальные стены и река Фиагдон.','Canyon in Kurtat valley1.jpg'],
['Куртатинское ущелье — каньон 2','gorge','Второй ракурс Кадаргаванского направления.','Canyon in Kurtat valley2.jpg'],
['Куртатинское ущелье — каньон 3','gorge','Глубокий каньон и горная дорога.','Canyon in Kurtat valley3.jpg'],
['Фиагдон','nature','Куртатинское ущелье. Зелёная долина Фиагдона.','Fiagdon.jpg'],
['Дзивгис и река Фиагдон','village','Старое селение Дзивгис в Куртатинском ущелье.','North Ossetia–Alania. Kurtat Valley. Dzivgis. Fiagdon River PA160688 2575.jpg'],
['Аланский Успенский монастырь','culture','Куртатинское ущелье, одна из самых узнаваемых архитектурных точек маршрута.','North Ossetia–Alania. Kurtat Valley. Alan Monastery of the Dormition of the Theotokos PA160650 2575.jpg'],
['Галиат — древнее селение','village','Горная Дигория. Каменные дома и башни старого Галиата.','Galiat-011.jpg'],
['Галиат — панорама','village','Высокогорное селение Галиат в Ирафском районе.','North Ossetia–Alania. Irafsky District. Galiat PA191426 2575.jpg'],
['Караугом — лес и ледник 1','nature','Дигория. Маршрут к Караугомскому леднику через густой горный лес.','Karaugom-001.jpg'],
['Караугом — ледниковая долина','nature','Долина Караугомдона и высокогорные массивы.','Karaugom-002.jpg'],
['Караугом — горная тропа','nature','Пешеходный маршрут Национального парка «Алания».','Karaugom-004.jpg'],
['Караугом — вертикальный ракурс','nature','Скальные стены и ледниковый ландшафт Дигории.','Karaugom-006.jpg'],
['Дигория — «Порог неба» 1','nature','Горная Дигория, район туристской базы и панорамных троп.','North Ossetia–Alania. Digoria. Turbaza Porog Neba PA181143 2575.jpg'],
['Дигория — «Порог неба» 2','nature','Ещё один вид на лесистые склоны и вершины Дигории.','North Ossetia–Alania. Digoria. Turbaza Porog Neba PA181212 2575.jpg'],
['Задалеск','village','Нижний Задалеск, историческая часть Горной Дигории.','North Ossetia–Alania. Nizhnii Zadalesk. ZIL-157 PA181056 2575.jpg'],
['Лезгор — долина Уруха','nature','Горная Дигория. Облачная долина реки Урух.','Лезгор, Осетия, Долина Урух в облаках.jpg'],
['Донифарс–Лезгорский некрополь','culture','Дигория. Исторический некрополь и старые каменные сооружения.','Лезгор, Осетия, Донифарско-Лезгорский некрополь, Lezgor, Ossetia.jpg'],
['Сказское ущелье','gorge','Цейский район. Скалы и ледниковая долина Сказского ущелья.','Skazskoe Gorge.jpg'],
['Сказское ущелье — альплагерь','gorge','Вид из района альплагеря в сторону высоких стен ущелья.','Skazsky gorge near the alpine camp.jpg'],
['Сказское ущелье — северо-запад','gorge','Панорамный ракурс на снежные вершины и долину.','Skazsky gorge near the alpine camp. View in the north-west direction.jpg'],
['Танадон','nature','Дигория. Долина реки Танадон и высокогорные склоны.','Tanandon-001.jpg'],
['Башня Цаллаговых','culture','Одна из фамильных башен Осетии — каменная оборонительная архитектура.','Башня Цаллаговых 2.jpg'],
['Святилище Реком','culture','Цейское ущелье. Один из важнейших традиционных культовых комплексов Осетии.','Реком 1.JPG'],
['Верхний Згид','village','Высокогорный посёлок и дорога среди хребтов Алагирского района.','Verkhniy Zgid urban-type settlement.jpg'],
['Казбек — вид со стороны Осетии','nature','Высокогорная панорама Казбека и прилегающих хребтов.','Survey Mt. Kazbek 27.05.2019.jpg']
];
const grid=document.getElementById('grid');
const fallbackPhotos=['dargavs','keli','tsey','kurtat','galiat','ikorta','khardisar','beloti','vladikavkaz','tiri','dzivgis','tskhinval'];
function localPhoto(label,index){
 const l=label.toLowerCase();
 const named=[['даргавс','dargavs'],['кель','keli'],['кели','keli'],['цей','tsey'],['цеи','tsey'],['кармадон','kurtat'],['галиат','galiat'],['дигор','galiat'],['куртат','kurtat'],['згид','tiri'],['башня','ikorta']];
 const match=named.find(([key])=>l.includes(key));
 const name=match?match[1]:fallbackPhotos[index%fallbackPhotos.length];
 return '/Niko-games/beauty/media/'+name+'.jpg';
}
function fileUrl(f){return C+encodeURIComponent(f)+'?width=1100'}
function render(filter='all'){
 grid.innerHTML='';
 places.filter(p=>filter==='all'||p[1]===filter).forEach((p,i)=>{
  const card=document.createElement('article'); card.className='place';
  const original=fileUrl(p[3]); const local=localPhoto(p[0],i);
  const offline=navigator.onLine===false;
  const link='https://commons.wikimedia.org/wiki/File:'+encodeURIComponent(p[3]).replace(/%20/g,'_');
  card.innerHTML=`<div class="place-media"><img loading="lazy" src="${offline?local:original}" alt="${p[0]}"></div><div class="place-copy"><span class="v14-badge">${String(i+1).padStart(2,'0')} / 40</span><h2>${p[0]}</h2><p>${p[2]}</p><small>📍 Северная Осетия — Алания</small><div class="credit"><a href="${link}" target="_blank" rel="noopener">Фото места: Wikimedia Commons ↗</a></div></div>`;
  const img=card.querySelector('img'); const credit=card.querySelector('.credit');
  function showLocal(){img.onerror=null;img.src=local;img.alt='Иллюстрация горной Осетии, не фотография конкретного места';card.classList.add('place-using-local'); if(!credit.querySelector('.local-photo-note')){const note=document.createElement('span');note.className='local-photo-note';note.textContent='Офлайн-иллюстрация · ';credit.prepend(note)}}
  img.onerror=showLocal;
  if(offline)showLocal();
  grid.append(card);
 });
}
document.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-f]').forEach(x=>x.classList.remove('active'));b.classList.add('active');render(b.dataset.f);audio.fx('tap')});render();
addEventListener('online',()=>render(document.querySelector('[data-f].active')?.dataset.f||'all'));
addEventListener('offline',()=>render(document.querySelector('[data-f].active')?.dataset.f||'all'));
addEventListener('pointerdown',()=>audio.recover(),{passive:true,once:true});
})();
