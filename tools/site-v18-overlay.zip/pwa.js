/* Updates the app shell without reloading a running game or deleting player data. */
(() => {
  'use strict';
  if (window.ArcadePWA) return;
  // Release protocol: keep this cache identity in sync with sw.js and repair.html.
  // A ready older shell is not proof that this release's new files are cached.
  const EXPECTED_SHELL_CACHE = 'niko-arcade-offline-v18';
  let registration = null;
  let starting = null;
  let preparing = null;
  let preparingWorker = null;
  let checking = null;
  let lastCheck = 0;
  let state = { ready: false, supported: 'serviceWorker' in navigator };
  let retroPreparing = null;
  let retroPreparingWorker = null;
  let retroObserved = false;
  let retroState = { ready: false, packageReady: false, supported: state.supported, preparing: false,
    completed: 0, total: 0, bytesCompleted: 0, bytesTotal: 0, missing: [], errors: [] };
  const watched = new WeakSet();

  function isCurrentShell(result) {
    return result?.type === 'OFFLINE_STATUS' && result.cache === EXPECTED_SHELL_CACHE && typeof result.ready === 'boolean';
  }

  function publish(next) {
    // Ignore obsolete replies, including delayed broadcasts after the new worker
    // has verified its files. Initial readiness stays unknown/false until v10.
    if (next.type === 'OFFLINE_STATUS' && !isCurrentShell(next)) return state;
    state = { ...state, ...next };
    window.dispatchEvent(new CustomEvent('arcade-offline-state', { detail: state }));
    window.dispatchEvent(new Event(state.ready ? 'arcade-offline-ready' : 'arcade-offline-failed'));
    if (retroState.total > 0 && !retroState.preparing) {
      // The small shell can finish after the larger package status was read.
      // Reuse that verified package result instead of hashing 30 MB again.
      publishRetro({ shellReady: state.ready, shellMissing: state.missing || [],
        ready: state.ready && retroState.packageReady === true });
    }
    return state;
  }

  function publishRetro(next) {
    retroState = { ...retroState, ...next };
    window.dispatchEvent(new CustomEvent('arcade-retro-offline-state', { detail: retroState }));
    return retroState;
  }

  function activeWorker() { return registration?.active || navigator.serviceWorker?.controller; }

  function ask(worker, type, timeout = 5000) {
    if (!worker || typeof MessageChannel === 'undefined') return Promise.resolve(null);
    return new Promise(resolve => {
      const channel = new MessageChannel();
      let finished = false;
      const done = value => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        channel.port1.close();
        channel.port2.close();
        resolve(value);
      };
      const timer = setTimeout(() => done(null), timeout);
      channel.port1.onmessage = event => done(event.data);
      channel.port1.onmessageerror = () => done(null);
      try { worker.postMessage({ type }, [channel.port2]); } catch { done(null); }
    });
  }

  async function status() {
    const worker = registration?.active || navigator.serviceWorker?.controller;
    const result = await ask(worker, 'GET_OFFLINE_STATUS');
    if (worker !== activeWorker()) return status();
    if (result?.type === 'OFFLINE_STATUS') return publish(result);
    return publish({ ready: false });
  }

  async function prepare() {
    const worker = registration?.active || navigator.serviceWorker?.controller;
    if (preparing && preparingWorker === worker) return preparing;
    if (!worker) return status();
    preparingWorker = worker;
    const task = (async () => {
      let known = await ask(worker, 'GET_OFFLINE_STATUS');
      if (worker !== (registration?.active || navigator.serviceWorker?.controller)) return status();
      // controllerchange/activation starts a separate preparation for the new
      // worker; do not let the old worker's ready reply short-circuit that work.
      if (known?.type === 'OFFLINE_STATUS' && !isCurrentShell(known)) return state;
      if (isCurrentShell(known) && known.ready) return publish(known);
      // A larger set of pronunciation clips may exceed one worker time budget
      // on mobile Wi-Fi. Continue only while the verified missing set shrinks;
      // retries are bounded and never reload the current game.
      for (let pass = 0; pass < 3 && isCurrentShell(known) && !known.ready && navigator.onLine; pass++) {
        const before = known.missing?.length ?? Infinity;
        const prepared = await ask(worker, 'PREPARE_OFFLINE', 65000);
        if (worker !== activeWorker()) return status();
        if (!isCurrentShell(prepared)) break;
        publish(prepared);
        known = prepared;
        if (known.ready || (known.missing?.length ?? Infinity) >= before) break;
      }
      return status();
    })().finally(() => { if (preparing === task) { preparing = null; preparingWorker = null; } });
    preparing = task;
    return task;
  }

  async function waitForActiveWorker() {
    await start();
    if (activeWorker()) return activeWorker();
    if (!navigator.serviceWorker?.ready) return null;
    let timer;
    try {
      await Promise.race([
        navigator.serviceWorker.ready,
        new Promise(resolve => { timer = setTimeout(resolve, 10000); }),
      ]);
    } catch { /* Report a retryable status below. */ }
    finally { clearTimeout(timer); }
    return activeWorker();
  }

  async function retroStatus() {
    retroObserved = true;
    const worker = await waitForActiveWorker();
    const result = await ask(worker, 'GET_RETRO_OFFLINE_STATUS', 15000);
    if (worker && worker !== activeWorker()) return retroStatus();
    if (result?.type === 'RETRO_OFFLINE_STATUS' && typeof result.ready === 'boolean') return publishRetro(result);
    return publishRetro({ ready: false, packageReady: false, preparing: false,
      errors: [{ path: '', reason: !state.supported ? 'unsupported' : 'not-ready' }] });
  }

  async function prepareRetro() {
    retroObserved = true;
    const worker = await waitForActiveWorker();
    if (retroPreparing && retroPreparingWorker === worker) return retroPreparing;
    if (!worker) return retroStatus();
    retroPreparingWorker = worker;
    const task = (async () => {
      publishRetro({ preparing: true, ready: false, errors: [] });
      // Progress is delivered through service-worker messages. The port reply is
      // the final verified result, not merely acknowledgement of a download.
      const result = await ask(worker, 'PREPARE_RETRO_OFFLINE', 95000);
      if (worker !== activeWorker()) return retroStatus();
      if (result?.type === 'RETRO_OFFLINE_STATUS' && typeof result.ready === 'boolean') return publishRetro(result);
      const current = await ask(worker, 'GET_RETRO_OFFLINE_STATUS', 15000);
      if (worker !== activeWorker()) return retroStatus();
      if (current?.type === 'RETRO_OFFLINE_STATUS' && typeof current.ready === 'boolean') return publishRetro(current);
      return publishRetro({ ready: false, packageReady: false, preparing: false, errors: [{ path: '', reason: 'timeout' }] });
    })().finally(() => {
      if (retroPreparing === task) { retroPreparing = null; retroPreparingWorker = null; }
    });
    retroPreparing = task;
    return task;
  }

  function watch(worker) {
    if (!worker || watched.has(worker)) return;
    watched.add(worker);
    worker.addEventListener('statechange', () => {
      if (worker.state === 'activated') void prepare();
      if (worker.state === 'redundant') void status();
    });
  }

  function start() {
    if (starting) return starting;
    if (!state.supported) return Promise.resolve(publish({ ready: false }));
    starting = navigator.serviceWorker.register('/Niko-games/sw.js', { scope: '/Niko-games/', updateViaCache: 'none' })
      .then(reg => {
        registration = reg;
        watch(reg.installing);
        watch(reg.waiting);
        reg.addEventListener('updatefound', () => watch(reg.installing));
        if (reg.active) void prepare();
        return reg;
      })
      .catch(() => {
        starting = null;
        publish({ ready: false });
        return null;
      });
    return starting;
  }

  async function check() {
    if (checking || document.hidden || !navigator.onLine) return checking;
    const now = Date.now();
    if (now - lastCheck < 60000 && registration) return;
    lastCheck = now;
    checking = (async () => {
      const reg = await start();
      if (!reg) return;
      try { await reg.update(); } catch { /* Cached games remain usable offline. */ }
      await prepare();
    })().finally(() => { checking = null; });
    return checking;
  }

  window.ArcadePWA = { start, status, prepare, retroStatus, prepareRetro,
    get state() { return state; }, get retroState() { return retroState; } };
  if (state.supported) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      // No location.reload(): a new worker must never interrupt a live game.
      void prepare();
      if (retroObserved) void retroStatus();
    });
    navigator.serviceWorker.addEventListener('message', event => {
      if (event.source && event.source !== activeWorker()) return;
      if (event.data?.type === 'OFFLINE_STATUS') publish(event.data);
      if (event.data?.type === 'RETRO_OFFLINE_STATUS') publishRetro(event.data);
    });
  }
  window.addEventListener('online', () => { lastCheck = 0; void check(); });
  window.addEventListener('pageshow', () => { void check(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) void check(); });
  if (document.readyState === 'complete') void start();
  else window.addEventListener('load', () => { void start(); }, { once: true });
})();
