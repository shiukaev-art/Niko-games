'use strict';

// These are app assets only. Profiles, ROMs and save states are never removed.
const VERSION = 18;
const CACHE = 'niko-arcade-offline-v18';
// Runtime and cartridges have immutable, verified contents. Keep them across
// shell upgrades instead of deleting a large download after every UI change.
const RETRO_CACHE = 'niko-retro-pinned-4.2.3-v1';
const SITE_BASE = new URL(self.registration.scope).pathname.replace(/\/$/, '');
const sitePath = path => SITE_BASE + path;
const logicalPath = path => SITE_BASE ? (path.startsWith(SITE_BASE + '/') ? path.slice(SITE_BASE.length) : null) : path;

const RETRO_VERSION = '4.2.3';
const RETRO_BASE = '/retro/runtime/' + RETRO_VERSION + '/data/';
const RETRO_MANIFEST = '/retro/runtime/' + RETRO_VERSION + '/offline-manifest.json';
const RETRO_CATALOG = '/retro/catalog.json';
const ASSETS = [
  // FAMILY_RELEASE_ASSETS_START
  '/compat.js',
  '/feedback/feedback.css',
  '/feedback/feedback.js',
  '/feedback/index.html',
  '/help/connection.html',
  '/help/connection.js',
  '/intro.css',
  '/intro.js',
  '/retro/controller.html',
  '/retro/tv-controller.js',
  '/retro/tv-core.js',
  '/retro/tv-host.js',
  '/retro/tv-launch.js',
  '/retro/tv.css',
  '/retro/tv.html',
  // intro now consists of a single text-only slide
  // FAMILY_RELEASE_ASSETS_END



  '/index.html', '/club.html', '/club.css', '/club.js', '/arcade.js', '/pwa.js', '/install.js', '/modern-audio.js', '/menu-music.js',
  '/v14-common.css', '/kids/sofia.html', '/kids/math.html', '/kids/math.js', '/kids/coloring.html', '/kids/coloring.js',
  '/adventures/fishing.html', '/beauty/places40.html', '/beauty/places40.js',

  '/display.js', '/display.css',
  '/games/snake.html', '/games/tetris.html', '/games/runner.html', '/runner.js',
  '/games/obby.html', '/games/sudoku.html', '/newgames.js', '/newgames.css',
  '/premium/neon.html', '/premium/magic.html', '/premium/styles.css',
  '/premium/engine.js', '/premium/model.js', '/premium/storage.js',
  '/premium/classic.css', '/premium/classic.js',
  '/ossetia/theme.css', '/ossetia/mountains-leopard.png', '/ossetia/mountain-lake.png',
  '/retro/index.html', '/retro/library.js', '/retro/player.html',
  '/retro/player.js', '/retro/retro.css', '/retro/emulator.html', '/retro/emulator.js',
  '/retro/controls.js', '/retro/controls.css', '/retro/catalog.js', RETRO_CATALOG, RETRO_MANIFEST,
  '/ossetian/index.html', '/ossetian/quiz.css', '/ossetian/quiz.js',
  '/ossetian/model.js', '/ossetian/words.js',
  '/ossetian/media/kurtat.jpg', '/ossetian/media/dargavs.jpg', '/ossetian/media/ossetian-song.mp3',
  '/retro/netplay-core.js',
  '/retro/netplay-host.js',
  '/retro/netplay-guest.js',
  '/retro/netplay-pad.js',
  '/retro/netplay.css',
  '/retro/join.html',
  '/ossetian/speech.js',
  '/ossetian/speech.css',
  '/ossetian/speech-manifest.json',
  '/beauty/index.html',
  '/beauty/beauty.css',
  '/beauty/beauty.js',
  '/beauty/model.js',
  '/beauty/data.js',
  '/beauty/credits.json',
  '/beauty/media/beloti.jpg',
  '/beauty/media/dargavs.jpg',
  '/beauty/media/dzivgis.jpg',
  '/beauty/media/galiat.jpg',
  '/beauty/media/ikorta.jpg',
  '/beauty/media/keli.jpg',
  '/beauty/media/khardisar.jpg',
  '/beauty/media/kurtat.jpg',
  '/beauty/media/pair-costume.jpg',
  '/beauty/media/tiri.jpg',
  '/beauty/media/tsey.jpg',
  '/beauty/media/tskhinval.jpg',
  '/beauty/media/vladikavkaz.jpg',
  '/beauty/media/women-costume.jpg',
  '/ossetian/audio/beauty-belt.mp3',
  '/ossetian/audio/beauty-burka.mp3',
  '/ossetian/audio/beauty-cap.mp3',
  '/ossetian/audio/beauty-cherkeska.mp3',
  '/ossetian/audio/beauty-dagger.mp3',
  '/ossetian/audio/beauty-dargavs.mp3',
  '/ossetian/audio/beauty-dress.mp3',
  '/ossetian/audio/beauty-dzivgis.mp3',
  '/ossetian/audio/beauty-galiat.mp3',
  '/ossetian/audio/beauty-keli.mp3',
  '/ossetian/audio/beauty-kurtat.mp3',
  '/ossetian/audio/beauty-tsey.mp3',
  '/ossetian/audio/beauty-tskhinval.mp3',
  '/ossetian/audio/beauty-veil.mp3',
  '/ossetian/audio/beauty-vladikavkaz.mp3',
  '/ossetian/audio/os-iron-001.mp3',
  '/ossetian/audio/os-iron-002.mp3',
  '/ossetian/audio/os-iron-003.mp3',
  '/ossetian/audio/os-iron-004.mp3',
  '/ossetian/audio/os-iron-005.mp3',
  '/ossetian/audio/os-iron-006.mp3',
  '/ossetian/audio/os-iron-007.mp3',
  '/ossetian/audio/os-iron-008.mp3',
  '/ossetian/audio/os-iron-009.mp3',
  '/ossetian/audio/os-iron-010.mp3',
  '/ossetian/audio/os-iron-011.mp3',
  '/ossetian/audio/os-iron-012.mp3',
  '/ossetian/audio/os-iron-013.mp3',
  '/ossetian/audio/os-iron-014.mp3',
  '/ossetian/audio/os-iron-015.mp3',
  '/ossetian/audio/os-iron-016.mp3',
  '/ossetian/audio/os-iron-017.mp3',
  '/ossetian/audio/os-iron-018.mp3',
  '/ossetian/audio/os-iron-019.mp3',
  '/ossetian/audio/os-iron-020.mp3',
  '/ossetian/audio/os-iron-021.mp3',
  '/ossetian/audio/os-iron-022.mp3',
  '/ossetian/audio/os-iron-023.mp3',
  '/ossetian/audio/os-iron-024.mp3',
  '/ossetian/audio/os-iron-025.mp3',
  '/ossetian/audio/os-iron-026.mp3',
  '/ossetian/audio/os-iron-027.mp3',
  '/ossetian/audio/os-iron-028.mp3',
  '/ossetian/audio/os-iron-029.mp3',
  '/ossetian/audio/os-iron-030.mp3',
  '/ossetian/audio/os-iron-031.mp3',
  '/ossetian/audio/os-iron-032.mp3',
  '/ossetian/audio/os-iron-033.mp3',
  '/ossetian/audio/os-iron-034.mp3',
  '/ossetian/audio/os-iron-035.mp3',
  '/ossetian/audio/os-iron-036.mp3',
  '/ossetian/audio/os-iron-037.mp3',
  '/ossetian/audio/os-iron-038.mp3',
  '/ossetian/audio/os-iron-039.mp3',
  '/ossetian/audio/os-iron-040.mp3',
  '/ossetian/audio/os-iron-041.mp3',
  '/ossetian/audio/os-iron-042.mp3',
  '/ossetian/audio/os-iron-043.mp3',
  '/ossetian/audio/os-iron-044.mp3',
  '/ossetian/audio/os-iron-045.mp3',
  '/ossetian/audio/os-iron-046.mp3',
  '/ossetian/audio/os-iron-047.mp3',
  '/ossetian/audio/os-iron-048.mp3',
  '/ossetian/audio/os-iron-049.mp3',
  '/ossetian/audio/os-iron-050.mp3',
  '/ossetian/audio/os-iron-051.mp3',
  '/ossetian/audio/os-iron-052.mp3',
  '/ossetian/audio/os-iron-053.mp3',
  '/ossetian/audio/os-iron-054.mp3',
  '/ossetian/audio/os-iron-055.mp3',
  '/ossetian/audio/os-iron-056.mp3',
  '/ossetian/audio/os-iron-057.mp3',
  '/ossetian/audio/os-iron-058.mp3',
  '/ossetian/audio/os-iron-059.mp3',
  '/ossetian/audio/os-iron-060.mp3',
  '/ossetian/audio/os-iron-061.mp3',
  '/ossetian/audio/os-iron-062.mp3',
  '/ossetian/audio/os-iron-063.mp3',
  '/ossetian/audio/os-iron-064.mp3',
  '/ossetian/audio/os-iron-065.mp3',
  '/ossetian/audio/os-iron-066.mp3',
  '/ossetian/audio/os-iron-067.mp3',
  '/ossetian/audio/os-iron-068.mp3',
  '/ossetian/audio/os-iron-069.mp3',
  '/ossetian/audio/os-iron-070.mp3',
  '/ossetian/audio/os-iron-071.mp3',
  '/ossetian/audio/os-iron-072.mp3',
  '/ossetian/audio/os-iron-073.mp3',
  '/ossetian/audio/os-iron-074.mp3',
  '/ossetian/audio/os-iron-075.mp3',
  // Cultural album, expanded pronunciation and the online-table interface.
  '/ossetian/audio/os-iron-076.mp3',
  '/ossetian/audio/os-iron-077.mp3',
  '/ossetian/audio/os-iron-078.mp3',
  '/ossetian/audio/os-iron-079.mp3',
  '/ossetian/audio/os-iron-080.mp3',
  '/ossetian/audio/os-iron-081.mp3',
  '/ossetian/audio/os-iron-082.mp3',
  '/ossetian/audio/os-iron-083.mp3',
  '/ossetian/audio/os-iron-084.mp3',
  '/ossetian/audio/os-iron-085.mp3',
  '/ossetian/audio/os-iron-086.mp3',
  '/ossetian/audio/os-iron-087.mp3',
  '/ossetian/audio/os-iron-088.mp3',
  '/ossetian/audio/os-iron-089.mp3',
  '/ossetian/audio/os-iron-090.mp3',
  '/ossetian/audio/os-iron-091.mp3',
  '/ossetian/audio/os-iron-092.mp3',
  '/ossetian/audio/os-iron-093.mp3',
  '/ossetian/audio/os-iron-094.mp3',
  '/ossetian/audio/os-iron-095.mp3',
  '/ossetian/audio/os-iron-096.mp3',
  '/ossetian/audio/os-iron-097.mp3',
  '/ossetian/audio/os-iron-098.mp3',
  '/ossetian/audio/os-iron-099.mp3',
  '/ossetian/audio/os-iron-100.mp3',
  '/ossetian/audio/os-iron-101.mp3',
  '/ossetian/audio/os-iron-102.mp3',
  '/ossetian/audio/os-iron-103.mp3',
  '/ossetian/audio/os-iron-104.mp3',
  '/ossetian/audio/os-iron-105.mp3',
  '/ossetian/audio/os-iron-106.mp3',
  '/ossetian/audio/os-iron-107.mp3',
  '/ossetian/audio/os-iron-108.mp3',
  '/ossetian/audio/os-iron-109.mp3',
  '/ossetian/audio/os-iron-110.mp3',
  '/ossetian/audio/os-iron-111.mp3',
  '/ossetian/audio/os-iron-112.mp3',
  '/ossetian/audio/os-iron-113.mp3',
  '/ossetian/audio/os-iron-114.mp3',
  '/ossetian/audio/os-iron-115.mp3',
  '/ossetian/audio/os-iron-116.mp3',
  '/ossetian/audio/os-iron-117.mp3',
  '/ossetian/audio/os-iron-118.mp3',
  '/ossetian/audio/os-iron-119.mp3',
  '/ossetian/audio/os-iron-120.mp3',
  '/ossetian/audio/os-iron-121.mp3',
  '/ossetian/audio/os-iron-122.mp3',
  '/ossetian/audio/os-iron-123.mp3',
  '/ossetian/audio/os-iron-124.mp3',
  '/ossetian/audio/os-iron-125.mp3',
  '/ossetian/audio/os-iron-126.mp3',
  '/ossetian/audio/os-iron-127.mp3',
  '/ossetian/audio/os-iron-128.mp3',
  '/ossetian/audio/os-iron-129.mp3',
  '/ossetian/audio/os-iron-130.mp3',
  '/ossetian/audio/os-iron-131.mp3',
  '/ossetian/audio/os-iron-132.mp3',
  '/ossetian/audio/os-iron-133.mp3',
  '/ossetian/audio/os-iron-134.mp3',
  '/ossetian/audio/os-iron-135.mp3',
  '/ossetian/audio/os-iron-136.mp3',
  '/ossetian/audio/os-iron-137.mp3',
  '/ossetian/audio/os-iron-138.mp3',
  '/ossetian/audio/os-iron-139.mp3',
  '/ossetian/audio/os-iron-140.mp3',
  '/ossetian/audio/os-iron-141.mp3',
  '/ossetian/audio/os-iron-142.mp3',
  '/ossetian/audio/os-iron-143.mp3',
  '/ossetian/audio/os-iron-144.mp3',
  '/ossetian/audio/os-iron-145.mp3',
  '/ossetian/audio/os-iron-146.mp3',
  '/ossetian/audio/os-iron-147.mp3',
  '/ossetian/audio/os-iron-148.mp3',
  '/ossetian/audio/os-iron-149.mp3',
  '/ossetian/audio/os-iron-150.mp3',
  '/beauty/media/dzinaga.jpg',
  '/beauty/media/ertso.jpg',
  '/beauty/media/frigate.jpg',
  '/beauty/media/kamunta.jpg',
  '/beauty/media/kvaysa.jpg',
  '/beauty/media/largvisi.jpg',
  '/beauty/media/leningor-palace.jpg',
  '/beauty/media/midagrabin.jpg',
  '/beauty/media/nar.jpg',
  '/beauty/media/nuzal.jpg',
  '/beauty/media/zadalesk.jpg',
  '/beauty/media/zaramag.jpg',
  '/heritage/credits.json',
  '/heritage/data.js',
  '/heritage/heritage.css',
  '/heritage/heritage.js',
  '/heritage/index.html',
  '/heritage/media/abaev.jpg',
  '/heritage/media/conservatory.jpg',
  '/heritage/media/gatsalov.jpg',
  '/heritage/media/gazdanov.jpg',
  '/heritage/media/gergiev.jpg',
  '/heritage/media/kosta.jpg',
  '/heritage/media/pies.jpg',
  '/heritage/media/simd.jpg',
  '/heritage/media/tuganov-museum.jpg',
  '/heritage/model.js',
  '/backgrounds.js',
  ...Array.from({ length: 11 }, (_, i) => '/photos/' + (i + 1) + '.jpeg'),
  '/manifest.webmanifest', '/icon-180.png', '/icon-192.png', '/icon-512.png',
];
// Core functionality is usable offline before the optional photos and audio finish.
const CORE_ASSETS = ASSETS.filter(path => /\.(?:html|js|css|json|webmanifest)$/.test(path));
const ASSET_PATHS = new Set(ASSETS);
const PAGE_PATHS = new Set(ASSETS.filter(path => path.endsWith('.html')));
// The production static host canonicalizes .html to extensionless URLs and
// directory/index.html to directory/. These aliases all identify one file.
const PAGE_ALIASES = new Map([['/', '/club.html']]);
for (const path of PAGE_PATHS) {
  PAGE_ALIASES.set(path, path);
  PAGE_ALIASES.set(path.slice(0, -5), path);
  if (path.endsWith('/index.html')) {
    const directory = path.slice(0, -10);
    PAGE_ALIASES.set(directory, path);
    PAGE_ALIASES.set(directory.slice(0, -1), path);
  }
}
let preparation;
let retroPreparation, retroPlanPromise, retroLastStatus;

function isOlderCache(name) {
  const match = /^niko-arcade-offline-v(\d+)$/.exec(name);
  return match && Number(match[1]) < VERSION;
}

function validMetadata(response, path) {
  if (!response || response.status !== 200 ||
      ['error', 'opaque', 'opaqueredirect'].includes(response.type)) return false;
  // Never turn authentication/error pages into games. Only this exact origin
  // and the requested static file are acceptable final response locations.
  if (response.url) {
    const finalURL = new URL(response.url);
    const actual = logicalPath(finalURL.pathname);
    const sameFile = PAGE_PATHS.has(path)
      ? PAGE_ALIASES.get(actual) === path : actual === path;
    if (finalURL.origin !== self.location.origin || !sameFile) return false;
  } else if (response.redirected) return false;
  const type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (path.endsWith('.html')) return type === 'text/html' || type === 'application/xhtml+xml';
  if (path.endsWith('.js')) return /^(text|application)\/(javascript|ecmascript)$/.test(type);
  if (path.endsWith('.css')) return type === 'text/css';
  if (path.endsWith('.webmanifest')) return type === 'application/manifest+json' || type === 'application/json';
  if (path.endsWith('.json')) return type === 'application/json' || type === 'text/json';
  if (path.endsWith('.png')) return type === 'image/png';
  if (/\.jpe?g$/.test(path)) return type === 'image/jpeg';
  if (path.endsWith('.webp')) return type === 'image/webp';
  if (path.endsWith('.mp3')) return type === 'audio/mpeg';
  if (path.endsWith('.ogg')) return type === 'audio/ogg' || type === 'application/ogg';
  if (path.endsWith('.wasm')) return type === 'application/wasm' || type === 'application/octet-stream';
  if (/\.(data|gen)$/.test(path)) return type !== 'text/html' && type !== 'application/xhtml+xml' && type !== 'application/json';
  return false;
}

function validHTML(text, path) {
  // All mini-games have their own entry scripts, not necessarily arcade.js.
  // Require a real NIKO HTML shell; reject soft-200 errors and login screens.
  return /^\s*<!doctype\s+html/i.test(text) && /<html\b/i.test(text) &&
    /<title[^>]*>[^<]+<\/title>/i.test(text.slice(0,9000)) &&
    !/<title[^>]*>[^<]*(?:404|not found|sign in|access denied)<\/title>/i.test(text.slice(0,9000));
}

function validJSON(text, path) {
  try {
    const json = JSON.parse(text);
    if (path === RETRO_MANIFEST) return json?.version === RETRO_VERSION &&
      Array.isArray(json.files) && json.files.length > 0 && json.files.length <= 200 &&
      json.files.every(entry => validRetroEntry(entry, true));
    if (path === RETRO_CATALOG) return json?.version === 1 &&
      Array.isArray(json.games) && json.games.length > 0 && json.games.length <= 100 &&
      json.games.every(entry => entry.system === 'segaMD' && validRetroEntry(entry, false));
    return json !== null && typeof json === 'object';
  } catch { return false; }
}

async function cleanResponse(response, path) {
  if (!validMetadata(response, path)) throw new Error('Unexpected asset response');
  const headers = new Headers(response.headers);
  // Fetch exposes decoded bytes: do not replay the old transport encoding.
  for (const name of ['content-encoding', 'content-length', 'transfer-encoding', 'location']) {
    headers.delete(name);
  }
  let body;
  if (PAGE_PATHS.has(path)) {
    body = await response.text();
    if (!validHTML(body, path)) throw new Error('Unexpected HTML page');
  } else if (path.endsWith('.json')) {
    body = await response.text();
    if (!validJSON(body, path)) throw retroFailure('manifest', 'Unexpected JSON asset');
  } else body = await response.arrayBuffer();
  // Cloning a redirected Response is insufficient on Safari. A fresh Response
  // has no redirect history and keeps the original ?id=... in Window.location.
  return new Response(body, { status: 200, statusText: 'OK', headers });
}

async function fetchFresh(path, timeout = 8000) {
  const controller = new AbortController();
  let timer;
  const expired = new Promise((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new Error('Asset request timed out'));
    }, timeout);
  });
  try {
    // Avoid the framework's '/' redirect. The static host's exact HTML aliases
    // are accepted after fetch; same-origin mode rejects cross-origin sign-in.
    // cleanResponse rejects any same-origin auth/unknown final URL as well.
    const request = new Request(new URL(sitePath(path), self.location.origin), {
      method: 'GET', mode: 'same-origin', credentials: 'same-origin',
      redirect: 'follow', cache: 'no-store', signal: controller.signal,
    });
    return await Promise.race([
      fetch(request).then(response => cleanResponse(response, path)), expired,
    ]);
  } finally { clearTimeout(timer); }
}

async function saveCurrent(path, response) {
  try {
    const cache = await caches.open(CACHE);
    await cache.put(sitePath(path), response.clone());
  } catch {
    // Quota/private-storage failure must not break a successful online load.
  }
}

async function cachedResponse(path) {
  try {
    const names = await caches.keys();
    const legacy = names.filter(isOlderCache).sort((a, b) =>
      Number(b.match(/v(\d+)$/)[1]) - Number(a.match(/v(\d+)$/)[1]));
    for (const name of (/(?:\.html|\.css|\.js|\.json|\.webmanifest)$/.test(path) ? [CACHE] : [CACHE, ...legacy])) {
      if (!names.includes(name)) continue;
      try {
        const cache = await caches.open(name);
        const response = await cache.match(sitePath(path));
        if (response) return await cleanResponse(response, path);
      } catch {
        // Skip invalid legacy items. Do not promote old code into the new cache.
      }
    }
  } catch {}
  return null;
}

async function offlineStatus() {
  let missing = [...ASSETS];
  try {
    const cache = await caches.open(CACHE);
    const checks = await Promise.all(ASSETS.map(async path => {
      try {
        const response = await cache.match(sitePath(path));
        if (!validMetadata(response, path)) return path;
        if (PAGE_PATHS.has(path) && !validHTML(await response.text(), path)) return path;
        if (path.endsWith('.json') && !validJSON(await response.text(), path)) return path;
        return null;
      } catch { return path; }
    }));
    missing = checks.filter(Boolean);
  } catch {}
  const coreMissing = missing.filter(path => CORE_ASSETS.includes(path));
  return { type: 'OFFLINE_STATUS', cache: CACHE, ready: missing.length === 0,
    coreReady: coreMissing.length === 0, missingCore: coreMissing, missing };
}

async function broadcast(status) {
  try {
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clients) {
      try { client.postMessage(status); } catch {}
    }
  } catch {}
}

async function cleanup(status) {
  try {
    const names = await caches.keys();
    await Promise.all(names.filter(name =>
      // This old mutable CDN cache contains no user ROMs or save states.
      name === 'niko-retro-runtime-v1' || (status.ready && isOlderCache(name))
    ).map(name => caches.delete(name).catch(() => false)));
  } catch {}
}

function assetPriority(path) { return /\.(?:html|js|css|webmanifest)$/.test(path) ? 0 : /\.json$/.test(path) ? 1 : /\.(?:wasm|data)$/.test(path) ? 2 : 3; }
function prepareOffline() {
  if (preparation) return preparation;
  preparation = (async () => {
    const before = await offlineStatus();
    const todo = [...before.missing].sort((a,b)=>assetPriority(a)-assetPriority(b));
    const deadline = Date.now() + 40000;
    let next = 0;
    async function fill() {
      while (next < todo.length && Date.now() < deadline) {
        const path = todo[next++];
        try { await saveCurrent(path, await fetchFresh(path)); } catch {}
      }
    }
    // A failed image never blocks activation or removes the last offline copy.
    await Promise.all(Array.from({ length: Math.min(3, todo.length) }, fill));
    const status = await offlineStatus();
    await cleanup(status);
    await broadcast(status);
    return status;
  })();
  preparation.then(() => { preparation = null; }, () => { preparation = null; });
  return preparation;
}

function retroFailure(reason, message) {
  return Object.assign(new Error(message), { reason });
}

function validRetroEntry(entry, runtime) {
  if (!entry || typeof entry.path !== 'string' || !Number.isSafeInteger(entry.size) ||
      entry.size < 1 || entry.size > 64 * 1024 * 1024 ||
      typeof entry.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(entry.sha256)) return false;
  // No arbitrary URLs, encoded traversal, user profile files or open cache proxy.
  const pattern = runtime
    ? /^\/retro\/runtime\/4\.2\.3\/data\/[a-zA-Z0-9_./-]+\.(js|css|json|data|wasm)$/
    : /^\/retro\/roms\/[a-z0-9-]+\.gen$/;
  return pattern.test(entry.path) && !entry.path.includes('..') && !entry.path.includes('//');
}

async function retroJSON(path) {
  let response;
  try {
    const stored = await (await caches.open(CACHE)).match(sitePath(path));
    if (stored) response = await cleanResponse(stored, path);
  } catch {}
  if (!response) {
    response = await fetchFresh(path);
    await saveCurrent(path, response);
  }
  try { return await response.json(); }
  catch { throw retroFailure('manifest', 'Invalid offline metadata'); }
}

function retroPlan() {
  if (retroPlanPromise) return retroPlanPromise;
  const task = (async () => {
    const [runtime, catalog] = await Promise.all([retroJSON(RETRO_MANIFEST), retroJSON(RETRO_CATALOG)]);
    if (runtime?.version !== RETRO_VERSION || !Array.isArray(runtime.files) ||
        !runtime.files.length || runtime.files.length > 200 ||
        catalog?.version !== 1 || !Array.isArray(catalog.games) ||
        !catalog.games.length || catalog.games.length > 100 ||
        !runtime.files.every(entry => validRetroEntry(entry, true)) ||
        !catalog.games.every(entry => entry.system === 'segaMD' && validRetroEntry(entry, false))) {
      throw retroFailure('manifest', 'Unexpected offline package');
    }
    const files = [...runtime.files, ...catalog.games].map(entry => ({
      path: entry.path, size: entry.size, sha256: entry.sha256,
    }));
    if (new Set(files.map(file => file.path)).size !== files.length ||
        files.reduce((sum, file) => sum + file.size, 0) > 256 * 1024 * 1024) {
      throw retroFailure('manifest', 'Invalid offline package size');
    }
    return { files, byPath: new Map(files.map(file => [file.path, file])), games: catalog.games.length };
  })();
  retroPlanPromise = task;
  task.catch(() => { if (retroPlanPromise === task) retroPlanPromise = null; });
  return task;
}

async function checkedRetroResponse(response, entry) {
  if (!validMetadata(response, entry.path)) throw retroFailure('integrity', 'Unexpected cartridge or runtime response');
  const bytes = await response.arrayBuffer();
  if (bytes.byteLength !== entry.size) throw retroFailure('integrity', 'Incomplete cartridge or runtime file');
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const hash = Array.from(new Uint8Array(digest), value => value.toString(16).padStart(2, '0')).join('');
  if (hash !== entry.sha256) throw retroFailure('integrity', 'Cartridge or runtime checksum mismatch');
  const headers = new Headers(response.headers);
  for (const name of ['content-encoding', 'content-length', 'transfer-encoding', 'location']) headers.delete(name);
  headers.set('content-length', String(bytes.byteLength));
  // Return a new Response here as well: never replay redirect history in Safari.
  return new Response(bytes, { status: 200, statusText: 'OK', headers });
}

async function cachedRetro(entry) {
  try {
    const response = await (await caches.open(RETRO_CACHE)).match(sitePath(entry.path));
    return response ? await checkedRetroResponse(response, entry) : null;
  } catch { return null; }
}

async function saveRetro(entry, response) {
  try { await (await caches.open(RETRO_CACHE)).put(sitePath(entry.path), response.clone()); }
  catch { throw retroFailure('storage', 'Offline storage is unavailable or full'); }
}

async function inspectRetro(plan) {
  const missing = [];
  let completed = 0, bytesCompleted = 0, next = 0;
  async function inspect() {
    while (next < plan.files.length) {
      const entry = plan.files[next++];
      if (await cachedRetro(entry)) { completed++; bytesCompleted += entry.size; }
      else missing.push(entry.path);
    }
  }
  // Bound memory: each file is hashed separately, never concatenate the pack.
  await Promise.all(Array.from({ length: 3 }, inspect));
  const shell = await offlineStatus();
  return {
    type: 'RETRO_OFFLINE_STATUS', cache: RETRO_CACHE, version: RETRO_VERSION,
    ready: !missing.length && shell.ready, packageReady: !missing.length, preparing: false,
    completed, total: plan.files.length, games: plan.games,
    bytesCompleted, bytesTotal: plan.files.reduce((sum, entry) => sum + entry.size, 0),
    missing, shellReady: shell.ready, shellMissing: shell.missing, errors: [],
  };
}

function unavailableRetroStatus(error) {
  return { type: 'RETRO_OFFLINE_STATUS', cache: RETRO_CACHE, version: RETRO_VERSION,
    ready: false, packageReady: false, preparing: false, completed: 0, total: 0, games: 0,
    bytesCompleted: 0, bytesTotal: 0, missing: [], shellReady: false, shellMissing: [],
    errors: [{ path: RETRO_MANIFEST, reason: error?.reason || 'network' }] };
}

async function retroStatus() {
  if (retroPreparation && retroLastStatus?.preparing) return retroLastStatus;
  try { return await inspectRetro(await retroPlan()); }
  catch (error) { return unavailableRetroStatus(error); }
}

function prepareRetroOffline() {
  if (retroPreparation) return retroPreparation;
  const task = (async () => {
    // The same command prepares the entry page and all app UI. Large game and
    // emulator downloads start only after this explicit user action.
    const shellTask = prepareOffline();
    try {
      const plan = await retroPlan();
      const before = await inspectRetro(plan);
      retroLastStatus = { ...before, preparing: true };
      await broadcast(retroLastStatus);
      const todo = before.missing.map(path => plan.byPath.get(path));
      const missing = new Set(before.missing);
      const errors = [];
      const deadline = Date.now() + 50000;
      let next = 0, completed = before.completed, bytesCompleted = before.bytesCompleted;
      let stopReason = self.navigator?.onLine === false && todo.length ? 'network' : null;
      async function fill() {
        while (next < todo.length && Date.now() < deadline && !stopReason) {
          const entry = todo[next++];
          try {
            if (self.navigator?.onLine === false) throw retroFailure('network', 'Offline');
            const response = await checkedRetroResponse(await fetchFresh(entry.path, 30000), entry);
            await saveRetro(entry, response);
            missing.delete(entry.path);
            completed++; bytesCompleted += entry.size;
          } catch (error) {
            const reason = error?.reason || 'network';
            errors.push({ path: entry.path, reason });
            if (reason === 'storage') stopReason = 'storage';
          }
          retroLastStatus = { ...before, preparing: true, ready: false, packageReady: !missing.size, completed, bytesCompleted,
            missing: Array.from(missing), errors: [...errors] };
          await broadcast(retroLastStatus);
        }
      }
      await Promise.all(Array.from({ length: Math.min(3, todo.length) }, fill));
      await shellTask;
      const status = await inspectRetro(plan);
      status.errors = errors.filter(error => status.missing.includes(error.path));
      // A resumable time budget avoids an indefinitely running worker on a slow
      // connection. Already verified files are retained for the next attempt.
      if (next < todo.length) status.errors.push({ path: '', reason: stopReason || 'time-budget' });
      if (!status.shellReady) status.errors.push({ path: '', reason: 'missing-shell' });
      retroLastStatus = status;
    } catch (error) {
      await shellTask;
      retroLastStatus = unavailableRetroStatus(error);
    }
    await broadcast(retroLastStatus);
    return retroLastStatus;
  })();
  retroPreparation = task;
  task.finally(() => { if (retroPreparation === task) retroPreparation = null; }).catch(() => {});
  return task;
}

async function serveRetro(path, request) {
  let entry;
  try { entry = (await retroPlan()).byPath.get(path); } catch { return unavailable(false); }
  // Source/license files outside the runtime manifest stay available online,
  // but are never silently included in or advertised as the offline package.
  if (!entry) return fetch(request);
  const cached = await cachedRetro(entry);
  if (cached) return cached;
  try {
    const response = await checkedRetroResponse(await fetchFresh(path, 30000), entry);
    try { await saveRetro(entry, response); } catch { /* Online play still works if storage is full. */ }
    return response;
  } catch { return unavailable(false); }
}

function unavailable(navigation) {
  if (!navigation) return new Response('This file is not available offline yet.', {
    status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
  });
  return new Response(`<!doctype html><html lang="ru"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#101722"><title>NIKO ARCADE — подключение</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#101722;color:#f7e7c6;font:16px/1.6 system-ui,sans-serif}main{max-width:32rem;padding:28px}h1{font-size:26px}button,a{display:inline-block;margin:8px 12px 0 0;padding:12px 18px;border:0;border-radius:12px;background:#efd096;color:#282017;font:inherit;text-decoration:none}p{color:#c5c9d2}</style>
<main><h1>Ждём подключение</h1><p>Эта игра ещё не сохранена для запуска без интернета. При восстановлении связи она откроется автоматически. Картриджи и рекорды остаются на устройстве.</p><button type="button" onclick="location.reload()">Попробовать снова</button><a href="${sitePath('/club.html')}">К выбору игр</a></main>
<script>addEventListener('online',()=>location.reload(),{once:true});</script></html>`, {
    status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

async function serve(path, navigation) {
  const cached = await cachedResponse(path);
  const isMedia = /\.(png|jpe?g|webp|mp3|ogg)$/.test(path);
  if (cached && !navigation) return cached;
  if (cached && self.navigator?.onLine === false) return cached;
  try {
    // Prefer the current HTML on reconnect; fall back to the last verified file.
    const response = await fetchFresh(path, cached ? 4000 : 10000);
    await saveCurrent(path, response);
    return response;
  } catch { return cached || unavailable(navigation); }
}

async function audioRange(path, request) {
  // Mobile media elements often ask for bytes even when the full MP3 was
  // downloaded already. Only known app audio can be served this way; a 206
  // response is never inserted into the full-file cache.
  const full = await serve(path, false);
  if (full.status !== 200) return full;
  const bytes = await full.arrayBuffer(), size = bytes.byteLength;
  const range = request.headers.get('range').match(/^bytes=(\d*)-(\d*)$/);
  const invalid = () => new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + size, 'Cache-Control': 'no-store' } });
  if (!range || (!range[1] && !range[2])) return invalid();
  let start = range[1] ? Number(range[1]) : Math.max(0, size - Number(range[2]));
  let end = range[1] && range[2] ? Math.min(size - 1, Number(range[2])) : size - 1;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start > end || start >= size || (!range[1] && Number(range[2]) === 0)) return invalid();
  const headers = new Headers(full.headers);
  headers.set('Accept-Ranges', 'bytes'); headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + size);
  headers.set('Content-Length', String(end - start + 1));
  return new Response(bytes.slice(start, end + 1), { status: 206, statusText: 'Partial Content', headers });
}

self.addEventListener('install', event => {
  // Replace the broken handler even when network/cache preparation is failing.
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    await self.clients.claim();
    const status = await offlineStatus();
    await cleanup(status);
    await broadcast(status);
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  // /repair.html, sign-in, APIs, unknown routes and any external CDN bypass this
  // worker. Large retro assets are served only after the pinned manifest check.
  if (url.searchParams.has('niko-direct')) return; // explicit un-intercepted online retry
  const local = logicalPath(url.pathname);
  if (request.method !== 'GET' || url.origin !== self.location.origin || local === null || local.startsWith('/api/')) return;
  if (request.headers.has('range')) {
    if (ASSET_PATHS.has(local) && /\.(mp3|ogg)$/.test(local)) event.respondWith(audioRange(local, request).catch(() => unavailable(false)));
    return;
  }
  const navigation = request.mode === 'navigate';
  const path = navigation ? (PAGE_ALIASES.get(local) || local) : local;
  if (!navigation && (path.startsWith(RETRO_BASE) || /^\/retro\/roms\/[a-z0-9-]+\.gen$/.test(path))) {
    event.respondWith(serveRetro(path, request).catch(() => unavailable(false)));
    return;
  }
  if (!(navigation ? PAGE_PATHS : ASSET_PATHS).has(path)) return;
  const response = serve(path, navigation).catch(() => unavailable(navigation));
  event.respondWith(response);
  if (navigation) event.waitUntil(response.then(() => prepareOffline()).catch(() => {}));
});

self.addEventListener('message', event => {
  const type = event.data?.type;
  if (!['GET_OFFLINE_STATUS', 'PREPARE_OFFLINE', 'GET_RETRO_OFFLINE_STATUS', 'PREPARE_RETRO_OFFLINE'].includes(type)) return;
  const work = type === 'PREPARE_OFFLINE' ? prepareOffline()
    : type === 'GET_RETRO_OFFLINE_STATUS' ? retroStatus()
      : type === 'PREPARE_RETRO_OFFLINE' ? prepareRetroOffline() : offlineStatus();
  event.waitUntil(work.then(status => {
    const recipient = event.ports?.[0] || event.source;
    try { recipient?.postMessage(status); } catch {}
  }).catch(() => {}));
});
