(function(root){
  'use strict';
  const categories=['traditions','people','heritage'];
  const plain=value=>JSON.parse(JSON.stringify(value));
  function validBank(bank){
    if(!bank||bank.version!==1||!Array.isArray(bank.entries)||!bank.entries.length)return false;
    const ids=new Set();
    for(const e of bank.entries){
      if(!e||typeof e.id!=='string'||!/^[a-z0-9-]+$/.test(e.id)||ids.has(e.id)||!categories.includes(e.category))return false;
      ids.add(e.id);
      if(!e.title||!e.quiz||typeof e.quiz.question!=='string'||!e.quiz.question.trim()||typeof e.quiz.answer!=='string'||!e.quiz.answer.trim()||!Array.isArray(e.quiz.distractors)||e.quiz.distractors.length!==2)return false;
      if(e.quiz.distractors.some(x=>typeof x!=='string'||!x.trim())||new Set([e.quiz.answer,...e.quiz.distractors]).size!==3)return false;
      if(typeof e.image!=='string'||!/^\/(?:heritage|beauty)\/media\/[a-z0-9-]+\.jpg$/.test(e.image))return false;
    }
    return true;
  }
  function fingerprint(bank){let h=2166136261;for(const ch of JSON.stringify(bank.entries.map(e=>[e.id,e.quiz,e.takeaway]))){h=Math.imul(h^ch.charCodeAt(0),16777619);}return(h>>>0).toString(16);}
  function shuffle(arr,rng){const out=arr.slice();for(let i=out.length-1;i>0;i--){let f=Number(rng());if(!Number.isFinite(f))f=0;const j=Math.floor(Math.min(.999999999,Math.max(0,f))*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
  function create(bank,rng=Math.random){
    if(!validBank(bank))throw new Error('Invalid heritage bank');
    // Every round covers traditions, people and places before adding four discoveries.
    const first=categories.flatMap(cat=>shuffle(bank.entries.filter(e=>e.category===cat),rng).slice(0,1));
    const selected=first.concat(shuffle(bank.entries.filter(e=>!first.includes(e)),rng)).slice(0,Math.min(7,bank.entries.length));
    return{version:1,bank:fingerprint(bank),index:0,finished:false,questions:shuffle(selected,rng).map(e=>({id:e.id,order:shuffle([0,1,2],rng),selected:null}))};
  }
  function question(state,bank){
    const record=state.questions[state.index],entry=bank.entries.find(e=>e.id===record.id);if(!entry)return null;
    const choices=[entry.quiz.answer,...entry.quiz.distractors];return{entry,choices:record.order.map(i=>choices[i]),correct:record.order.indexOf(0),selected:record.selected};
  }
  function answer(state,index){
    if(state.finished||!Number.isInteger(index)||index<0||index>2||state.questions[state.index].selected!==null)return state;
    const out=plain(state);out.questions[out.index].selected=index;return out;
  }
  function next(state){if(state.finished||state.questions[state.index].selected===null)return state;const out=plain(state);if(out.index===out.questions.length-1)out.finished=true;else out.index++;return out;}
  function summary(state){return{total:state.questions.length,answered:state.questions.filter(q=>q.selected!==null).length,correct:state.questions.filter(q=>q.selected!==null&&q.order[q.selected]===0).length};}
  function restore(raw,bank){
    try{
      const s=typeof raw==='string'?JSON.parse(raw):raw;if(!validBank(bank)||!s||s.version!==1||s.bank!==fingerprint(bank)||!Array.isArray(s.questions)||s.questions.length!==Math.min(7,bank.entries.length)||!Number.isInteger(s.index)||s.index<0||s.index>=s.questions.length||typeof s.finished!=='boolean')return null;
      const allowed=new Set(bank.entries.map(e=>e.id)),seen=new Set();
      for(let i=0;i<s.questions.length;i++){
        const q=s.questions[i];if(!q||!allowed.has(q.id)||seen.has(q.id)||!Array.isArray(q.order)||q.order.length!==3||q.order.some(x=>!Number.isInteger(x)||x<0||x>2)||new Set(q.order).size!==3||(q.selected!==null&&(!Number.isInteger(q.selected)||q.selected<0||q.selected>2)))return null;
        if(i<s.index&&q.selected===null||i>s.index&&q.selected!==null)return null;seen.add(q.id);
      }
      if(s.finished&&(s.index!==s.questions.length-1||s.questions.some(q=>q.selected===null)))return null;
      return{version:1,bank:s.bank,index:s.index,finished:s.finished,questions:s.questions.map(q=>({id:q.id,order:q.order.slice(),selected:q.selected}))};
    }catch{return null;}
  }
  function progress(raw,bank){
    const empty={version:1,read:[],bookmarks:[],best:0};
    try{const s=typeof raw==='string'?JSON.parse(raw):raw;if(!s||s.version!==1)return empty;const allowed=new Set(bank.entries.map(e=>e.id));const ids=x=>Array.isArray(x)?Array.from(new Set(x.filter(id=>typeof id==='string'&&allowed.has(id)))):[];return{version:1,read:ids(s.read),bookmarks:ids(s.bookmarks),best:Number.isInteger(s.best)&&s.best>=0&&s.best<=7?s.best:0};}catch{return empty;}
  }
  function toggle(progress,key,id,bank){if(!['read','bookmarks'].includes(key)||!bank.entries.some(e=>e.id===id))return progress;const out=plain(progress);out[key]=out[key].includes(id)?out[key].filter(x=>x!==id):out[key].concat(id);return out;}
  function normalize(text){return String(text||'').toLowerCase().replaceAll('ӕ','æ').replaceAll('ё','е').trim();}
  function filter(bank,{category='all',query='',savedOnly=false,bookmarks=[]}={}){const q=normalize(query);return bank.entries.filter(e=>(category==='all'||e.category===category)&&(!savedOnly||bookmarks.includes(e.id))&&(!q||normalize([e.title,e.kicker,e.summary,e.learningWord.word,e.learningWord.meaning].join(' ')).includes(q)));}
  const api={validBank,fingerprint,create,question,answer,next,summary,restore,progress,toggle,filter,normalize};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.OssetianHeritageModel=api;
})(typeof window!=='undefined'?window:globalThis);
