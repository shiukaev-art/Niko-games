import UIKit
import WebKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = GameViewController()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
}

final class GameViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private let primaryURL = URL(string: "https://niko-arcade-club.workspace-844979.chatgpt.site/")!
    private var webView: WKWebView!
    private var errorView: UIView?
    private var hasLoadedOnce = false
    private var foregroundObserver: NSObjectProtocol?

    override var prefersStatusBarHidden: Bool { true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { .all }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.backgroundColor = .black
        webView.isOpaque = false

        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        foregroundObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            guard let self, self.hasLoadedOnce else { return }
            self.loadFreshGame()
        }

        clearWebCachesAndLoad()
    }

    deinit {
        if let foregroundObserver {
            NotificationCenter.default.removeObserver(foregroundObserver)
        }
    }

    /// Clears only transient web caches and Service Worker registrations.
    /// Cookies and Local Storage are intentionally kept so game settings/progress survive updates.
    private func clearWebCachesAndLoad() {
        var dataTypes: Set<String> = [
            WKWebsiteDataTypeDiskCache,
            WKWebsiteDataTypeMemoryCache,
            WKWebsiteDataTypeOfflineWebApplicationCache
        ]

        // Service Worker registrations can keep serving an old PWA build.
        // Using the WebKit data type string keeps the project compatible across SDK versions.
        dataTypes.insert("WKWebsiteDataTypeServiceWorkerRegistrations")

        WKWebsiteDataStore.default().removeData(
            ofTypes: dataTypes,
            modifiedSince: .distantPast
        ) { [weak self] in
            DispatchQueue.main.async {
                self?.loadFreshGame()
            }
        }
    }

    private func freshURL() -> URL {
        var components = URLComponents(url: primaryURL, resolvingAgainstBaseURL: false)!
        var items = components.queryItems ?? []
        items.removeAll { $0.name == "niko_app_build" || $0.name == "refresh" }
        items.append(URLQueryItem(name: "niko_app_build", value: "2"))
        items.append(URLQueryItem(name: "refresh", value: String(Int(Date().timeIntervalSince1970))))
        components.queryItems = items
        return components.url ?? primaryURL
    }

    private func loadFreshGame() {
        errorView?.removeFromSuperview()
        errorView = nil

        let request = URLRequest(
            url: freshURL(),
            cachePolicy: .reloadIgnoringLocalCacheData,
            timeoutInterval: 30
        )
        webView.load(request)
    }

    private func showLoadError() {
        guard errorView == nil else { return }

        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false
        container.backgroundColor = .black

        let title = UILabel()
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = "NIKO application"
        title.textColor = .white
        title.font = .systemFont(ofSize: 26, weight: .bold)
        title.textAlignment = .center

        let message = UILabel()
        message.translatesAutoresizingMaskIntoConstraints = false
        message.text = "Не удалось загрузить свежую версию игры. Проверьте интернет и попробуйте ещё раз."
        message.textColor = .lightGray
        message.font = .systemFont(ofSize: 16)
        message.numberOfLines = 0
        message.textAlignment = .center

        let retry = UIButton(type: .system)
        retry.translatesAutoresizingMaskIntoConstraints = false
        retry.setTitle("Повторить", for: .normal)
        retry.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        retry.addTarget(self, action: #selector(retryTapped), for: .touchUpInside)

        container.addSubview(title)
        container.addSubview(message)
        container.addSubview(retry)
        view.addSubview(container)

        NSLayoutConstraint.activate([
            container.topAnchor.constraint(equalTo: view.topAnchor),
            container.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            container.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            container.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            title.centerYAnchor.constraint(equalTo: container.centerYAnchor, constant: -60),
            title.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 24),
            title.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -24),
            message.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 18),
            message.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 32),
            message.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -32),
            retry.topAnchor.constraint(equalTo: message.bottomAnchor, constant: 24),
            retry.centerXAnchor.constraint(equalTo: container.centerXAnchor)
        ])

        errorView = container
    }

    @objc private func retryTapped() {
        clearWebCachesAndLoad()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        hasLoadedOnce = true
        errorView?.removeFromSuperview()
        errorView = nil
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        showLoadError()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showLoadError()
    }

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        if let url = navigationAction.request.url {
            webView.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData))
        }
        return nil
    }
}
