# NIKO application — iOS

Готовая нативная оболочка для NIKO ARCADE.

## Как работает
Приложение открывает актуальную опубликованную игру:
https://niko-arcade-club.workspace-844979.chatgpt.site/

Поэтому после обновления веб-игры изменения появляются в приложении автоматически — новую iOS-сборку делать не нужно, пока не меняется сама оболочка.

## Первая сборка в Xcode
1. Открой `NIKOApplication.xcodeproj` на Mac.
2. В Project Navigator выбери проект `NIKOApplication` → TARGETS → `NIKOApplication`.
3. Открой `Signing & Capabilities`.
4. Выбери свою Apple Developer Team.
5. При необходимости замени Bundle Identifier `com.nikolay.shiukaev.nikoapplication` на уникальный идентификатор своей команды.
6. Подключи iPhone и нажми Run для проверки.

## TestFlight
1. В Xcode выбери `Any iOS Device (arm64)`.
2. `Product` → `Archive`.
3. В Organizer: `Distribute App` → `App Store Connect` → `Upload`.
4. В App Store Connect открой TestFlight и создай группу тестировщиков.
5. Для близких можно включить Public Link и отправить её сообщением.

## Версия
Display name: NIKO application
Version: 1.0.0
Build: 2
Bundle ID по умолчанию: com.nikolay.shiukaev.nikoapplication


## Build 2 — автообновление веб-игры
- CURRENT_PROJECT_VERSION: 2
- При каждом новом запуске/возврате приложения выполняется запрос свежей версии сайта.
- Используется cache-busting параметр `niko_app_build=2` + timestamp.
- Очищаются Disk/Memory/Offline cache и регистрации Service Worker.
- Cookies и Local Storage не очищаются, чтобы сохранить настройки/локальный прогресс игры.
